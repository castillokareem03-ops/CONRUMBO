import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color green = Color(0xFF08A65A);
const Color dark = Color(0xFF06354A);
const Color bg = Color(0xFFF7F9FA);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  runApp(ConRumboApp(store: store));
}

class ConRumboApp extends StatelessWidget {
  final AppStore store;

  const ConRumboApp({Key? key, required this.store}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'conrumbo',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        scaffoldBackgroundColor: bg,
      ),
      home: store.loggedIn
          ? HomeScreen(store: store)
          : AuthScreen(store: store),
    );
  }
}

class Trip {
  String origin;
  String destination;
  String date;
  String time;
  String price;
  String seats;
  String vehicle;
  String driver;
  String driverPhone;

  Trip({
    required this.origin,
    required this.destination,
    required this.date,
    required this.time,
    required this.price,
    required this.seats,
    required this.vehicle,
    this.driver = 'Carlos M.',
    this.driverPhone = '',
  });

  Map<String, dynamic> toJson() => {
        'origin': origin,
        'destination': destination,
        'date': date,
        'time': time,
        'price': price,
        'seats': seats,
        'vehicle': vehicle,
        'driver': driver,
        'driverPhone': driverPhone,
      };

  factory Trip.fromJson(Map<String, dynamic> json) {
    return Trip(
      origin: '${json['origin'] ?? ''}',
      destination: '${json['destination'] ?? ''}',
      date: '${json['date'] ?? ''}',
      time: '${json['time'] ?? ''}',
      price: '${json['price'] ?? ''}',
      seats: '${json['seats'] ?? '0'}',
      vehicle: '${json['vehicle'] ?? ''}',
      driver: '${json['driver'] ?? 'Carlos M.'}',
      driverPhone: '${json['driverPhone'] ?? ''}',
    );
  }
}

class Booking {
  String tripKey;
  String origin;
  String destination;
  String date;
  String time;
  String price;
  String seats;
  String vehicle;
  String driver;
  String passenger;
  String passengerPhone;
  String driverPhone;

  Booking({
    required this.tripKey,
    required this.origin,
    required this.destination,
    required this.date,
    required this.time,
    required this.price,
    required this.seats,
    required this.vehicle,
    required this.driver,
    required this.passenger,
    this.passengerPhone = '',
    this.driverPhone = '',
  });

  Map<String, dynamic> toJson() => {
        'tripKey': tripKey,
        'origin': origin,
        'destination': destination,
        'date': date,
        'time': time,
        'price': price,
        'seats': seats,
        'vehicle': vehicle,
        'driver': driver,
        'passenger': passenger,
        'passengerPhone': passengerPhone,
        'driverPhone': driverPhone,
      };

  factory Booking.fromJson(Map<String, dynamic> json) {
    return Booking(
      tripKey: '${json['tripKey'] ?? ''}',
      origin: '${json['origin'] ?? ''}',
      destination: '${json['destination'] ?? ''}',
      date: '${json['date'] ?? ''}',
      time: '${json['time'] ?? ''}',
      price: '${json['price'] ?? ''}',
      seats: '${json['seats'] ?? '1'}',
      vehicle: '${json['vehicle'] ?? ''}',
      driver: '${json['driver'] ?? ''}',
      passenger: '${json['passenger'] ?? ''}',
      passengerPhone: '${json['passengerPhone'] ?? ''}',
      driverPhone: '${json['driverPhone'] ?? ''}',
    );
  }
}

class AppStore {
  late SharedPreferences prefs;
  bool loggedIn = false;
  String name = '';
  String email = '';
  String phone = '';
  String identity = '';
  String license = '';
  String vehicleDetails = '';
  List<Trip> trips = [];
  List<Booking> bookings = [];

  Future<void> load() async {
    prefs = await SharedPreferences.getInstance();
    loggedIn = prefs.getBool('loggedIn') ?? false;
    name = prefs.getString('name') ?? '';
    email = prefs.getString('email') ?? '';
    phone = prefs.getString('phone') ?? '';
    identity = prefs.getString('identity') ?? '';
    license = prefs.getString('license') ?? '';
    vehicleDetails = prefs.getString('vehicleDetails') ?? '';

    final tripData = prefs.getString('trips');
    if (tripData != null) {
      final decoded = jsonDecode(tripData) as List<dynamic>;
      trips = decoded
          .map((item) => Trip.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    }

    final bookingData = prefs.getString('bookings');
    if (bookingData != null) {
      final decoded = jsonDecode(bookingData) as List<dynamic>;
      bookings = decoded
          .map((item) => Booking.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    }
  }

  Future<void> login(String userName, String userEmail) async {
    loggedIn = true;
    name = userName;
    email = userEmail;
    await prefs.setBool('loggedIn', true);
    await prefs.setString('name', name);
    await prefs.setString('email', email);
  }

  Future<void> updateProfile({String? newName, String? newPhone, String? newIdentity, String? newLicense, String? newVehicle}) async {
    if (newName != null) { name = newName; await prefs.setString('name', name); }
    if (newPhone != null) { phone = newPhone; await prefs.setString('phone', phone); }
    if (newIdentity != null) { identity = newIdentity; await prefs.setString('identity', identity); }
    if (newLicense != null) { license = newLicense; await prefs.setString('license', license); }
    if (newVehicle != null) { vehicleDetails = newVehicle; await prefs.setString('vehicleDetails', vehicleDetails); }
  }

  Future<void> logout() async {
    loggedIn = false;
    await prefs.setBool('loggedIn', false);
  }

  Future<void> addTrip(Trip trip) async {
    trips.insert(0, trip);
    await prefs.setString(
      'trips',
      jsonEncode(trips.map((item) => item.toJson()).toList()),
    );
  }

  Future<void> saveBookings() async {
    await prefs.setString(
      'bookings',
      jsonEncode(bookings.map((item) => item.toJson()).toList()),
    );
  }

  String tripKey(Trip trip) {
    return '${trip.origin}|${trip.destination}|${trip.date}|${trip.time}|${trip.driver}|${trip.vehicle}';
  }

  bool hasBooking(Trip trip) {
    return bookings.any((booking) => booking.tripKey == tripKey(trip));
  }

  Future<bool> addBooking(Trip trip) async {
    if (hasBooking(trip)) return false;
    final available = int.tryParse(trip.seats) ?? 0;
    if (available <= 0) return false;

    trip.seats = '${available - 1}';
    bookings.insert(
      0,
      Booking(
        tripKey: tripKey(trip),
        origin: trip.origin,
        destination: trip.destination,
        date: trip.date,
        time: trip.time,
        price: trip.price,
        seats: '1',
        vehicle: trip.vehicle,
        driver: trip.driver,
        passenger: name.isEmpty ? 'Usuario conrumbo' : name,
        passengerPhone: phone,
        driverPhone: trip.driverPhone,
      ),
    );

    await addTripListSave();
    await saveBookings();
    return true;
  }

  Future<void> addTripListSave() async {
    await prefs.setString(
      'trips',
      jsonEncode(trips.map((item) => item.toJson()).toList()),
    );
  }
}

class AuthScreen extends StatefulWidget {
  final AppStore store;

  const AuthScreen({Key? key, required this.store}) : super(key: key);

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = false;
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  Future<void> submit() async {
    final email = emailController.text.trim();
    final password = passwordController.text;
    final name = nameController.text.trim();

    if (email.isEmpty || password.length < 4 || (register && name.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Completa los datos correctamente.')),
      );
      return;
    }

    await widget.store.login(
      register ? name : 'Usuario conrumbo',
      email,
    );

    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => HomeScreen(store: widget.store)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Icon(Icons.alt_route, color: green, size: 72),
                const SizedBox(height: 8),
                const Text(
                  'conrumbo',
                  style: TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.w900,
                    color: dark,
                  ),
                ),
                const Text('Comparte el camino, llega más lejos.'),
                const SizedBox(height: 35),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Text(
                          register ? 'Crear cuenta' : 'Iniciar sesión',
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 18),
                        if (register)
                          TextField(
                            controller: nameController,
                            decoration: const InputDecoration(
                              labelText: 'Nombre completo',
                              prefixIcon: Icon(Icons.person),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        if (register) const SizedBox(height: 12),
                        TextField(
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            labelText: 'Correo electrónico',
                            prefixIcon: Icon(Icons.email),
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: passwordController,
                          obscureText: true,
                          decoration: const InputDecoration(
                            labelText: 'Contraseña',
                            prefixIcon: Icon(Icons.lock),
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: FilledButton(
                            onPressed: submit,
                            child: Text(register ? 'Crear cuenta' : 'Entrar'),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextButton(
                          onPressed: () => setState(() => register = !register),
                          child: Text(
                            register
                                ? 'Ya tengo una cuenta'
                                : 'Crear una cuenta',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text('Versión MVP · datos de prueba'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final AppStore store;

  const HomeScreen({Key? key, required this.store}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  final originController = TextEditingController(text: 'Monterrey, Nuevo León');
  final destinationController =
      TextEditingController(text: 'CDMX, Ciudad de México');
  DateTime date = DateTime(2026, 10, 5);
  int passengers = 1;

  void search() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ResultsScreen(
          store: widget.store,
          origin: originController.text,
          destination: destinationController.text,
          date: date,
          passengers: passengers,
        ),
      ),
    );
  }

  void publish() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PublishScreen(store: widget.store)),
    );
  }

  void profile() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ProfileScreen(store: widget.store)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            const SliverToBoxAdapter(child: HeroHeader()),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: SearchCard(
                  origin: originController,
                  destination: destinationController,
                  date: date,
                  passengers: passengers,
                  onDate: (value) => setState(() => date = value),
                  onPassengers: (value) => setState(() => passengers = value),
                  onSearch: search,
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Popular(
                onSelect: (value) {
                  destinationController.text = value;
                  setState(() {});
                },
              ),
            ),
            const SliverToBoxAdapter(child: SafetyCard()),
            const SliverToBoxAdapter(child: Benefits()),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (index) {
          setState(() => tab = index);
          if (index == 1) search();
          if (index == 2) publish();
          if (index == 3) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MyBookingsScreen(store: widget.store),
              ),
            );
          }
          if (index == 4) profile();
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Inicio',
          ),
          NavigationDestination(icon: Icon(Icons.search), label: 'Buscar'),
          NavigationDestination(
            icon: Icon(Icons.add_circle_outline),
            selectedIcon: Icon(Icons.add_circle),
            label: 'Publicar',
          ),
          NavigationDestination(
            icon: Icon(Icons.event_seat),
            label: 'Reservas',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }
}

class HeroHeader extends StatelessWidget {
  const HeroHeader({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [dark, Color(0xFF087A57)]),
      ),
      child: Stack(
        children: [
          const Positioned(
            left: 20,
            top: 18,
            child: Icon(Icons.menu, color: Colors.white, size: 30),
          ),
          const Positioned(
            right: 20,
            top: 18,
            child: Icon(
              Icons.notifications_none,
              color: Colors.white,
              size: 29,
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(Icons.alt_route, color: Color(0xFF28D97B), size: 44),
                    SizedBox(width: 5),
                    Text(
                      'con',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 40,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      'rumbo',
                      style: TextStyle(
                        color: Color(0xFF28D97B),
                        fontSize: 40,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Comparte el camino,\nllega más lejos',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SearchCard extends StatelessWidget {
  final TextEditingController origin;
  final TextEditingController destination;
  final DateTime date;
  final int passengers;
  final ValueChanged<DateTime> onDate;
  final ValueChanged<int> onPassengers;
  final VoidCallback onSearch;

  const SearchCard({
    Key? key,
    required this.origin,
    required this.destination,
    required this.date,
    required this.passengers,
    required this.onDate,
    required this.onPassengers,
    required this.onSearch,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Field(
              icon: Icons.location_on,
              color: green,
              label: 'Desde',
              controller: origin,
            ),
            Field(
              icon: Icons.location_on,
              color: Colors.redAccent,
              label: 'Hasta',
              controller: destination,
            ),
            ActionField(
              icon: Icons.calendar_month,
              label: 'Fecha de salida',
              value: '${date.day}/${date.month}/${date.year}',
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                  initialDate: date.isBefore(DateTime.now())
                      ? DateTime.now()
                      : date,
                );
                if (picked != null) onDate(picked);
              },
            ),
            ActionField(
              icon: Icons.person_outline,
              label: 'Pasajeros',
              value:
                  '$passengers ${passengers == 1 ? 'pasajero' : 'pasajeros'}',
              onTap: () async {
                int value = passengers;
                await showDialog<void>(
                  context: context,
                  builder: (dialogContext) {
                    return StatefulBuilder(
                      builder: (context, setDialogState) {
                        return AlertDialog(
                          title: const Text('Pasajeros'),
                          content: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(
                                onPressed: value > 1
                                    ? () => setDialogState(() => value--)
                                    : null,
                                icon: const Icon(
                                  Icons.remove_circle_outline,
                                ),
                              ),
                              Text(
                                '$value',
                                style: const TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              IconButton(
                                onPressed: value < 6
                                    ? () => setDialogState(() => value++)
                                    : null,
                                icon: const Icon(Icons.add_circle_outline),
                              ),
                            ],
                          ),
                          actions: [
                            FilledButton(
                              onPressed: () {
                                onPassengers(value);
                                Navigator.pop(dialogContext);
                              },
                              child: const Text('Guardar'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: FilledButton.icon(
                onPressed: onSearch,
                icon: const Icon(Icons.search),
                label: const Text(
                  'Buscar viajes',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Field extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final TextEditingController controller;

  const Field({
    Key? key,
    required this.icon,
    required this.color,
    required this.label,
    required this.controller,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: color),
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: const Color(0xFFF8FAFB),
        ),
      ),
    );
  }
}

class ActionField extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final VoidCallback onTap;

  const ActionField({
    Key? key,
    required this.icon,
    required this.label,
    required this.value,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 4),
      leading: Icon(icon),
      title: Text(label, style: const TextStyle(fontSize: 12)),
      subtitle: Text(
        value,
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
    );
  }
}

class Popular extends StatelessWidget {
  final ValueChanged<String> onSelect;

  const Popular({Key? key, required this.onSelect}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const destinations = [
      'CDMX, Ciudad de México',
      'Guadalajara, Jalisco',
      'Monterrey, Nuevo León',
      'Tijuana, Baja California',
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Destinos populares',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: destinations
                  .map(
                    (destination) => GestureDetector(
                      onTap: () => onSelect(destination),
                      child: Container(
                        width: 145,
                        height: 85,
                        margin: const EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          gradient: const LinearGradient(
                            colors: [Color(0xFF135B7A), Color(0xFF08A65A)],
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        padding: const EdgeInsets.all(9),
                        child: Text(
                          destination.split(',').first,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class SafetyCard extends StatelessWidget {
  const SafetyCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Card(
        color: dark,
        child: ListTile(
          leading: const Icon(
            Icons.verified_user,
            color: Color(0xFF28D97B),
            size: 36,
          ),
          title: const Text(
            'Viajes seguros',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          subtitle: const Text(
            'Verificación, calificaciones y herramientas de seguridad.',
            style: TextStyle(color: Colors.white70),
          ),
          trailing: TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => SafetyScreen()),
              );
            },
            child: const Text('Ver'),
          ),
        ),
      ),
    );
  }
}

class Benefits extends StatelessWidget {
  const Benefits({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(12, 0, 12, 20),
      child: Row(
        children: [
          Expanded(
            child: Benefit(
              icon: Icons.directions_car,
              title: 'Publica',
              text: 'Comparte tu ruta',
            ),
          ),
          Expanded(
            child: Benefit(
              icon: Icons.savings,
              title: 'Ahorra',
              text: 'Comparte gastos',
            ),
          ),
          Expanded(
            child: Benefit(
              icon: Icons.shield,
              title: 'Tranquilo',
              text: 'Verificación',
            ),
          ),
          Expanded(
            child: Benefit(
              icon: Icons.people,
              title: 'Conoce',
              text: 'Comunidad',
            ),
          ),
        ],
      ),
    );
  }
}

class Benefit extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const Benefit({
    Key? key,
    required this.icon,
    required this.title,
    required this.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 4),
        CircleAvatar(
          backgroundColor: Color(0xFFE2F6EC),
          child: Icon(icon, color: green),
        ),
        const SizedBox(height: 5),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)),
      ],
    );
  }
}

class ResultsScreen extends StatelessWidget {
  final AppStore store;
  final String origin;
  final String destination;
  final DateTime date;
  final int passengers;

  const ResultsScreen({
    Key? key,
    required this.store,
    required this.origin,
    required this.destination,
    required this.date,
    required this.passengers,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final matches = store.trips.where((trip) {
      return trip.origin
              .toLowerCase()
              .contains(origin.split(',').first.toLowerCase()) &&
          trip.destination
              .toLowerCase()
              .contains(destination.split(',').first.toLowerCase());
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Buscar viajes')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Text(
            '$origin → $destination',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Text(
            '${date.day}/${date.month}/${date.year} · $passengers pasajero(s)',
            style: const TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 12),
          if (matches.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(22),
                child: Text(
                  'No encontramos viajes con esos datos todavía. Puedes publicar el tuyo.',
                ),
              ),
            ),
          ...matches.map((trip) => TripCard(trip: trip, store: store)),
        ],
      ),
    );
  }
}

class TripCard extends StatelessWidget {
  final Trip trip;
  final AppStore store;

  const TripCard({
    Key? key,
    required this.trip,
    required this.store,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => TripDetail(trip: trip, store: store),
            ),
          );
        },
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                children: [
                  const CircleAvatar(child: Icon(Icons.person)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          trip.driver,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const Text(
                          '★ 4.8 · Verificado',
                          style: TextStyle(color: Colors.orange),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    trip.price,
                    style: const TextStyle(
                      color: green,
                      fontWeight: FontWeight.bold,
                      fontSize: 19,
                    ),
                  ),
                ],
              ),
              const Divider(),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${trip.time}\n${trip.origin.split(',').first} → ${trip.destination.split(',').first}',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('${trip.seats} asientos'),
                      Text(
                        trip.vehicle,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class TripDetail extends StatefulWidget {
  final Trip trip;
  final AppStore store;

  const TripDetail({
    Key? key,
    required this.trip,
    required this.store,
  }) : super(key: key);

  @override
  State<TripDetail> createState() => _TripDetailState();
}

class _TripDetailState extends State<TripDetail> {
  bool loading = false;

  Future<void> reserve() async {
    setState(() => loading = true);
    final success = await widget.store.addBooking(widget.trip);
    if (!mounted) return;
    setState(() => loading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success ? '¡Asiento reservado!' : 'No hay asientos disponibles.',
        ),
      ),
    );
    if (success) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final reserved = widget.store.hasBooking(widget.trip);

    return Scaffold(
      appBar: AppBar(title: const Text('Detalle del viaje')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const CircleAvatar(
            radius: 34,
            child: Icon(Icons.person, size: 38),
          ),
          const SizedBox(height: 8),
          Center(
            child: Text(
              '${widget.trip.driver} · ★ 4.8 · Verificado',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 17,
              ),
            ),
          ),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${widget.trip.origin} → ${widget.trip.destination}',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text('${widget.trip.date} · ${widget.trip.time}'),
                  Text('${widget.trip.seats} asientos disponibles'),
                  Text(widget.trip.vehicle),
                  const SizedBox(height: 12),
                  const Text(
                    'Compartir gastos del viaje',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'El monto mostrado corresponde a la aportación por asiento.',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 52,
            child: FilledButton(
              onPressed: loading || reserved ? null : reserve,
              child: Text(
                reserved
                    ? 'Asiento reservado'
                    : 'Reservar asiento · ${widget.trip.price}',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PublishScreen extends StatefulWidget {
  final AppStore store;

  const PublishScreen({Key? key, required this.store}) : super(key: key);

  @override
  State<PublishScreen> createState() => _PublishScreenState();
}

class _PublishScreenState extends State<PublishScreen> {
  final originController =
      TextEditingController(text: 'Monterrey, Nuevo León');
  final destinationController =
      TextEditingController(text: 'CDMX, Ciudad de México');
  final priceController = TextEditingController(text: '420');

  int seats = 3;
  String vehicle = 'Kia K3 · Gris';
  DateTime date = DateTime(2026, 10, 5);
  TimeOfDay time = const TimeOfDay(hour: 8, minute: 0);

  Future<void> submit() async {
    final trip = Trip(
      origin: originController.text.trim(),
      destination: destinationController.text.trim(),
      date: '${date.day}/${date.month}/${date.year}',
      time: time.format(context),
      price: '\$${priceController.text.trim()}',
      seats: '$seats',
      vehicle: vehicle,
      driver: widget.store.name.isEmpty ? 'Mi viaje' : widget.store.name,
        driverPhone: widget.store.phone,
    );

    await widget.store.addTrip(trip);
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('¡Viaje publicado!'),
        content: const Text(
          'Tu viaje se guardó en este dispositivo y ya aparece en el buscador.',
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Listo'),
          ),
        ],
      ),
    );

    if (mounted) Navigator.pop(context);
  }

  @override
  void dispose() {
    originController.dispose();
    destinationController.dispose();
    priceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Publicar viaje')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            '1 · Ruta',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Field(
            icon: Icons.location_on,
            color: green,
            label: 'Origen',
            controller: originController,
          ),
          Field(
            icon: Icons.location_on,
            color: Colors.red,
            label: 'Destino',
            controller: destinationController,
          ),
          const SizedBox(height: 12),
          const Text(
            '2 · Fecha y hora',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          ActionField(
            icon: Icons.calendar_month,
            label: 'Fecha',
            value: '${date.day}/${date.month}/${date.year}',
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 365)),
                initialDate: date,
              );
              if (picked != null) setState(() => date = picked);
            },
          ),
          ActionField(
            icon: Icons.schedule,
            label: 'Hora de salida',
            value: time.format(context),
            onTap: () async {
              final picked = await showTimePicker(
                context: context,
                initialTime: time,
              );
              if (picked != null) setState(() => time = picked);
            },
          ),
          const SizedBox(height: 8),
          const Text(
            '3 · Asientos y aportación',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          ListTile(
            title: const Text('Asientos disponibles'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed:
                      seats > 1 ? () => setState(() => seats--) : null,
                  icon: const Icon(Icons.remove_circle_outline),
                ),
                Text('$seats'),
                IconButton(
                  onPressed:
                      seats < 7 ? () => setState(() => seats++) : null,
                  icon: const Icon(Icons.add_circle_outline),
                ),
              ],
            ),
          ),
          TextField(
            controller: priceController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Aportación por asiento',
              prefixText: '\$ ',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            '4 · Vehículo',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          DropdownButtonFormField<String>(
            value: vehicle,
            items: const [
              'Kia K3 · Gris',
              'Toyota Corolla · Blanco',
              'Mazda 3 · Rojo',
              'Nissan Sentra · Negro',
            ]
                .map(
                  (item) => DropdownMenuItem<String>(
                    value: item,
                    child: Text(item),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (value != null) setState(() => vehicle = value);
            },
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 52,
            child: FilledButton(
              onPressed: submit,
              child: const Text(
                'Publicar viaje',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  final AppStore store;
  const ProfileScreen({Key? key, required this.store}) : super(key: key);

  Future<void> edit(BuildContext context) async {
    final name = TextEditingController(text: store.name);
    final phone = TextEditingController(text: store.phone);
    final identity = TextEditingController(text: store.identity);
    final license = TextEditingController(text: store.license);
    final vehicle = TextEditingController(text: store.vehicleDetails);
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Editar perfil y verificaciones'),
        content: SingleChildScrollView(
          child: Column(children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre')),
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Teléfono')),
            TextField(controller: identity, decoration: const InputDecoration(labelText: 'Identidad (nombre completo)')),
            TextField(controller: license, decoration: const InputDecoration(labelText: 'Licencia de conducir')),
            TextField(controller: vehicle, decoration: const InputDecoration(labelText: 'Vehículo (marca, modelo, placas)')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () async { await store.updateProfile(newName: name.text.trim(), newPhone: phone.text.trim(), newIdentity: identity.text.trim(), newLicense: license.text.trim(), newVehicle: vehicle.text.trim()); if (context.mounted) Navigator.pop(context); }, child: const Text('Guardar')),
        ],
      ),
    );
  }

  Future<void> logout(BuildContext context) async {
    await store.logout();
    if (!context.mounted) return;
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => AuthScreen(store: store)), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mi perfil'), actions: [IconButton(onPressed: () => edit(context), icon: const Icon(Icons.edit))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const CircleAvatar(radius: 45, child: Icon(Icons.person, size: 52)),
        const SizedBox(height: 10),
        Center(child: Text(store.name.isEmpty ? 'Usuario conrumbo' : store.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
        Center(child: Text(store.email)),
        if (store.phone.isNotEmpty) Center(child: Text(store.phone)),
        const SizedBox(height: 20),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.verified_user, color: green), title: const Text('Identidad'), trailing: Text(store.identity.isEmpty ? 'Pendiente' : 'Capturada')),
          ListTile(leading: const Icon(Icons.drive_eta, color: green), title: const Text('Licencia de conducir'), trailing: Text(store.license.isEmpty ? 'Pendiente' : 'Capturada')),
          ListTile(leading: const Icon(Icons.directions_car, color: green), title: const Text('Vehículo'), subtitle: store.vehicleDetails.isEmpty ? null : Text(store.vehicleDetails), trailing: Text(store.vehicleDetails.isEmpty ? 'Agregar' : 'Capturado')),
          ListTile(leading: const Icon(Icons.edit, color: green), title: const Text('Editar datos'), onTap: () => edit(context), trailing: const Icon(Icons.chevron_right)),
        ])),
        const SizedBox(height: 12),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.route), title: const Text('Mis viajes'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MyTripsScreen(store: store))), trailing: const Icon(Icons.chevron_right)),
          ListTile(leading: const Icon(Icons.event_seat, color: green), title: const Text('Mis reservas'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MyBookingsScreen(store: store))), trailing: const Icon(Icons.chevron_right)),
          ListTile(leading: const Icon(Icons.security), title: const Text('Centro de seguridad'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SafetyScreen())), trailing: const Icon(Icons.chevron_right)),
          ListTile(leading: const Icon(Icons.logout), title: const Text('Cerrar sesión'), onTap: () => logout(context)),
        ])),
      ]),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final String contactName;
  final String phone;
  const ChatScreen({Key? key, required this.contactName, required this.phone}) : super(key: key);
  @override State<ChatScreen> createState() => _ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  final messages = <String>[];
  @override Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text('Chat con ${widget.contactName}'), actions: [if (widget.phone.isNotEmpty) IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Teléfono: ${widget.phone}'))), icon: const Icon(Icons.phone))]),
      body: Column(children: [Expanded(child: messages.isEmpty ? const Center(child: Text('Envía un mensaje para contactar.')) : ListView.builder(padding: const EdgeInsets.all(12), itemCount: messages.length, itemBuilder: (_, i) => Align(alignment: Alignment.centerRight, child: Card(child: Padding(padding: const EdgeInsets.all(10), child: Text(messages[i])))))),
        SafeArea(child: Row(children: [Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Escribe un mensaje...', contentPadding: EdgeInsets.symmetric(horizontal: 12)))), IconButton(onPressed: () { final text = controller.text.trim(); if (text.isEmpty) return; setState(() { messages.add(text); controller.clear(); }); }, icon: const Icon(Icons.send, color: green))]))]);
  }
}

class MyTripsScreen extends StatelessWidget {
  final AppStore store;
  const MyTripsScreen({Key? key, required this.store}) : super(key: key);
  @override Widget build(BuildContext context) {
    final cards = store.trips.map<Widget>((trip) {
      final related = store.bookings.where((b) => b.tripKey == store.tripKey(trip)).toList();
      return Card(child: Column(children: [ListTile(leading: const Icon(Icons.route, color: green), title: Text('${trip.origin.split(',').first} → ${trip.destination.split(',').first}'), subtitle: Text('${trip.date} · ${trip.time} · ${trip.seats} asientos'), trailing: Text(trip.price, style: const TextStyle(fontWeight: FontWeight.bold))), if (related.isNotEmpty) ...[const Divider(height: 1), ...related.map((b) => ListTile(leading: const Icon(Icons.person), title: Text('Reserva: ${b.passenger}'), subtitle: Text(b.passengerPhone.isEmpty ? 'Teléfono no registrado' : b.passengerPhone), trailing: IconButton(icon: const Icon(Icons.chat, color: green), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(contactName: b.passenger, phone: b.passengerPhone)))))] ]));
    }).toList();
    return Scaffold(appBar: AppBar(title: const Text('Mis viajes')), body: cards.isEmpty ? const Center(child: Text('Todavía no tienes viajes publicados.')) : ListView(padding: const EdgeInsets.all(12), children: cards));
  }
}

class MyBookingsScreen extends StatelessWidget {
  final AppStore store;
  const MyBookingsScreen({Key? key, required this.store}) : super(key: key);
  @override Widget build(BuildContext context) {
    final cards = store.bookings.map<Widget>((b) => Card(child: Column(children: [ListTile(leading: const Icon(Icons.event_seat, color: green), title: Text('${b.origin.split(',').first} → ${b.destination.split(',').first}'), subtitle: Text('${b.date} · ${b.time}\nConductor: ${b.driver} · ${b.vehicle}'), isThreeLine: true, trailing: Text(b.price, style: const TextStyle(fontWeight: FontWeight.bold, color: green))), ListTile(leading: const Icon(Icons.chat, color: green), title: Text('Contactar a ${b.driver}'), subtitle: Text(b.driverPhone.isEmpty ? 'Agrega tu teléfono para habilitar contacto directo' : b.driverPhone), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(contactName: b.driver, phone: b.driverPhone))))]))).toList();
    return Scaffold(appBar: AppBar(title: const Text('Mis reservas')), body: cards.isEmpty ? const Center(child: Text('Todavía no tienes reservas.')) : ListView(padding: const EdgeInsets.all(12), children: cards));
  }
}

class SafetyScreen extends StatelessWidget {
  SafetyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Centro de seguridad')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SafetyItem(
            icon: Icons.verified_user,
            title: 'Verificación de identidad',
            subtitle: 'Ayuda a crear una comunidad de confianza.',
          ),
          const SafetyItem(
            icon: Icons.directions_car,
            title: 'Vehículos verificados',
            subtitle: 'Información del vehículo antes de viajar.',
          ),
          const SafetyItem(
            icon: Icons.star,
            title: 'Calificaciones',
            subtitle: 'Consulta las opiniones de otros usuarios.',
          ),
          const SafetyItem(
            icon: Icons.report_problem,
            title: 'Reportar un problema',
            subtitle: 'Herramientas de ayuda y seguridad.',
          ),
        ],
      ),
    );
  }
}

class SafetyItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const SafetyItem({
    Key? key,
    required this.icon,
    required this.title,
    required this.subtitle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: green),
        title: Text(title),
        subtitle: Text(subtitle),
      ),
    );
  }
}
