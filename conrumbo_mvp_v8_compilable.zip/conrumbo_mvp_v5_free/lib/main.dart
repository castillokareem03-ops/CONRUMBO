import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const green = Color(0xFF08A65A);
const dark = Color(0xFF06354A);
const bg = Color(0xFFF7F9FA);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  runApp(ConRumboApp(store: store));
}

class ConRumboApp extends StatelessWidget {
  final AppStore store;
  const ConRumboApp({super.key, required this.store});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'conrumbo',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: green), scaffoldBackgroundColor: bg),
    home: store.loggedIn ? HomeScreen(store: store) : AuthScreen(store: store),
  );
}

class Trip {
  String origin, destination, date, time, price, seats, vehicle, driver;
  Trip({required this.origin, required this.destination, required this.date, required this.time, required this.price, required this.seats, required this.vehicle, this.driver='Carlos M.'});
  Map<String,dynamic> toJson()=>{'origin':origin,'destination':destination,'date':date,'time':time,'price':price,'seats':seats,'vehicle':vehicle,'driver':driver};
  factory Trip.fromJson(Map<String,dynamic> j)=>Trip(origin:j['origin'],destination:j['destination'],date:j['date'],time:j['time'],price:j['price'],seats:j['seats'],vehicle:j['vehicle'],driver:j['driver']??'Carlos M.');
}

class Booking {
  String tripKey, origin, destination, date, time, price, seats, vehicle, driver, passenger;
  Booking({required this.tripKey, required this.origin, required this.destination, required this.date, required this.time, required this.price, required this.seats, required this.vehicle, required this.driver, required this.passenger});
  Map<String,dynamic> toJson()=>{'tripKey':tripKey,'origin':origin,'destination':destination,'date':date,'time':time,'price':price,'seats':seats,'vehicle':vehicle,'driver':driver,'passenger':passenger};
  factory Booking.fromJson(Map<String,dynamic> j)=>Booking(tripKey:j['tripKey']??'',origin:j['origin']??'',destination:j['destination']??'',date:j['date']??'',time:j['time']??'',price:j['price']??'',seats:j['seats']??'1',vehicle:j['vehicle']??'',driver:j['driver']??'',passenger:j['passenger']??'');
}

class AppStore {
  late SharedPreferences prefs;
  bool loggedIn=false;
  String name='';
  String email='';
  List<Trip> trips=[];
  List<Booking> bookings=[];
  Future<void> load() async {
    prefs=await SharedPreferences.getInstance();
    loggedIn=prefs.getBool('loggedIn')??false;
    name=prefs.getString('name')??'';
    email=prefs.getString('email')??'';
    final raw=prefs.getString('trips');
    if(raw!=null){ trips=(jsonDecode(raw) as List).map((e)=>Trip.fromJson(e)).toList(); }
    final rawBookings=prefs.getString('bookings');
    if(rawBookings!=null){ bookings=(jsonDecode(rawBookings) as List).map((e)=>Booking.fromJson(e)).toList(); }
    if(trips.isEmpty){
      trips=[
        Trip(origin:'Monterrey, Nuevo León',destination:'CDMX, Ciudad de México',date:'5 oct. 2026',time:'08:00 AM',price:'$420',seats:'3',vehicle:'Kia K3 · Gris'),
        Trip(origin:'Monterrey, Nuevo León',destination:'CDMX, Ciudad de México',date:'5 oct. 2026',time:'09:30 AM',price:'$450',seats:'2',vehicle:'Toyota Corolla · Blanco'),
        Trip(origin:'Monterrey, Nuevo León',destination:'CDMX, Ciudad de México',date:'5 oct. 2026',time:'11:00 AM',price:'$380',seats:'3',vehicle:'Mazda 3 · Rojo'),
      ];
      await saveTrips();
    }
  }
  Future<void> saveTrips() async=>prefs.setString('trips',jsonEncode(trips.map((e)=>e.toJson()).toList()));
  Future<void> login(String n,String e) async {name=n;email=e;loggedIn=true;await prefs.setBool('loggedIn',true);await prefs.setString('name',n);await prefs.setString('email',e);}
  Future<void> logout() async {loggedIn=false;await prefs.setBool('loggedIn',false);}
  Future<void> addTrip(Trip t) async {trips.insert(0,t);await saveTrips();}
  Future<void> saveBookings() async=>prefs.setString('bookings',jsonEncode(bookings.map((e)=>e.toJson()).toList()));
  bool hasBooking(Trip t)=>bookings.any((b)=>b.tripKey==tripKey(t));
  String tripKey(Trip t)=>'${t.origin}|${t.destination}|${t.date}|${t.time}|${t.driver}|${t.vehicle}';
  Future<bool> addBooking(Trip t) async { if(hasBooking(t)) return false; final available=int.tryParse(t.seats)??0; if(available<=0)return false; t.seats='${available-1}'; bookings.insert(0,Booking(tripKey:tripKey(t),origin:t.origin,destination:t.destination,date:t.date,time:t.time,price:t.price,seats:'1',vehicle:t.vehicle,driver:t.driver,passenger:name.isEmpty?'Usuario conrumbo':name)); await saveTrips(); await saveBookings(); return true; }
}

class AuthScreen extends StatefulWidget { final AppStore store; const AuthScreen({super.key,required this.store}); @override State<AuthScreen> createState()=>_AuthScreenState(); }
class _AuthScreenState extends State<AuthScreen>{
  bool register=false; final name=TextEditingController(); final email=TextEditingController(); final password=TextEditingController();
  Future<void> submit() async { if((register&&name.text.trim().isEmpty)||email.text.trim().isEmpty||password.text.length<4){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Completa los datos. La contraseña debe tener al menos 4 caracteres.')));return;} await widget.store.login(register?name.text.trim():'Usuario conrumbo',email.text.trim()); if(mounted)Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>HomeScreen(store:widget.store))); }
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:Column(children:[
    const Icon(Icons.alt_route,color:green,size:72), const SizedBox(height:8),
    const Text('conrumbo',style:TextStyle(fontSize:42,fontWeight:FontWeight.w900,color:dark)), const Text('Comparte el camino, llega más lejos.',style:TextStyle(color:Colors.black54)), const SizedBox(height:35),
    Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[Text(register?'Crear cuenta':'Iniciar sesión',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:18),
      if(register) TextField(controller:name,decoration:const InputDecoration(labelText:'Nombre completo',prefixIcon:Icon(Icons.person),border:OutlineInputBorder())), if(register) const SizedBox(height:12),
      TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'Correo electrónico',prefixIcon:Icon(Icons.email),border:OutlineInputBorder())),const SizedBox(height:12),
      TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Contraseña',prefixIcon:Icon(Icons.lock),border:OutlineInputBorder())),const SizedBox(height:20),
      SizedBox(width:double.infinity,height:50,child:FilledButton(onPressed:submit,child:Text(register?'Crear cuenta':'Entrar'))),const SizedBox(height:10),
      TextButton(onPressed:()=>setState(()=>register=!register),child:Text(register?'Ya tengo una cuenta':'Crear una cuenta')),
    ]))), const SizedBox(height:18),const Text('Versión MVP · datos de prueba',style:TextStyle(color:Colors.black45))
  ]))));
}

class HomeScreen extends StatefulWidget { final AppStore store; const HomeScreen({super.key,required this.store}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen>{
  int tab=0; final origin=TextEditingController(text:'Monterrey, Nuevo León'); final destination=TextEditingController(text:'CDMX, Ciudad de México'); DateTime date=DateTime(2026,10,5); int passengers=1;
  void search()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ResultsScreen(store:widget.store,origin:origin.text,destination:destination.text,date:date,passengers:passengers)));
  void publish()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PublishScreen(store:widget.store)));
  void profile()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProfileScreen(store:widget.store)));
  Future<void> pickDate()async{final d=await showDatePicker(context:context,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:365)),initialDate:date.isBefore(DateTime.now())?DateTime.now():date);if(d!=null)setState(()=>date=d);}
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:CustomScrollView(slivers:[const SliverToBoxAdapter(child:HeroHeader()),SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(16,0,16,16),child:SearchCard(origin:origin,destination:destination,date:date,passengers:passengers,onDate:(d)=>setState(()=>date=d),onPassengers:(p)=>setState(()=>passengers=p),onSearch:search))),SliverToBoxAdapter(child:Popular(onSelect:(v){destination.text=v;setState((){});})),const SliverToBoxAdapter(child:Safety()),const SliverToBoxAdapter(child:Benefits())])),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i){setState(()=>tab=i);if(i==1)search();if(i==2)publish();if(i==3)Navigator.push(context,MaterialPageRoute(builder:(_)=>MyBookingsScreen(store:widget.store)));if(i==4)profile();},destinations:const[NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Inicio'),NavigationDestination(icon:Icon(Icons.search),label:'Buscar'),NavigationDestination(icon:Icon(Icons.add_circle_outline),selectedIcon:Icon(Icons.add_circle),label:'Publicar'),NavigationDestination(icon:Icon(Icons.chat_bubble_outline),label:'Mensajes'),NavigationDestination(icon:Icon(Icons.person_outline),label:'Perfil')]));
}

class HeroHeader extends StatelessWidget{const HeroHeader({super.key});@override Widget build(BuildContext c)=>Container(height:220,decoration:const BoxDecoration(gradient:LinearGradient(colors:[dark,Color(0xFF087A57)])),child:Stack(children:[const Positioned(left:20,top:18,child:Icon(Icons.menu,color:Colors.white,size:30)),const Positioned(right:20,top:18,child:Icon(Icons.notifications_none,color:Colors.white,size:29)),Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Row(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.alt_route,color:Color(0xFF28D97B),size:44),const SizedBox(width:5),const Text('con',style:TextStyle(color:Colors.white,fontSize:40,fontWeight:FontWeight.w800)),const Text('rumbo',style:TextStyle(color:Color(0xFF28D97B),fontSize:40,fontWeight:FontWeight.w800))]),const SizedBox(height:8),const Text('Comparte el camino,\nllega más lejos',textAlign:TextAlign.center,style:TextStyle(color:Colors.white,fontSize:18,fontWeight:FontWeight.w600))]))]));}

class SearchCard extends StatelessWidget{final TextEditingController origin,destination;final DateTime date;final int passengers;final ValueChanged<DateTime> onDate;final ValueChanged<int> onPassengers;final VoidCallback onSearch;const SearchCard({super.key,required this.origin,required this.destination,required this.date,required this.passengers,required this.onDate,required this.onPassengers,required this.onSearch});
  @override Widget build(BuildContext c)=>Card(elevation:5,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(22)),child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[Field(icon:Icons.location_on,color:green,label:'Desde',controller:origin),Field(icon:Icons.location_on,color:Colors.redAccent,label:'Hasta',controller:destination),ActionField(icon:Icons.calendar_month,label:'Fecha de salida',value:'${date.day}/${date.month}/${date.year}',onTap:()async{final d=await showDatePicker(context:c,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:365)),initialDate:date);if(d!=null)onDate(d);}),ActionField(icon:Icons.person_outline,label:'Pasajeros',value:'$passengers ${passengers==1?'pasajero':'pasajeros'}',onTap:()async{int v=passengers;await showDialog(context:c,builder:(_)=>AlertDialog(title:const Text('Pasajeros'),content:StatefulBuilder(builder:(x,s)=>Row(mainAxisAlignment:MainAxisAlignment.center,children:[IconButton(onPressed:v>1?(){s(()=>v--):null,icon:const Icon(Icons.remove_circle_outline)),Text('$v',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),IconButton(onPressed:v<6?(){s(()=>v++):null,icon:const Icon(Icons.add_circle_outline))])),actions:[FilledButton(onPressed:(){onPassengers(v);Navigator.pop(c);},child:const Text('Guardar'))]));}),const SizedBox(height:8),SizedBox(width:double.infinity,height:52,child:FilledButton.icon(onPressed:onSearch,icon:const Icon(Icons.search),label:const Text('Buscar viajes',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold))))])));
}
class Field extends StatelessWidget{final IconData icon;final Color color;final String label;final TextEditingController controller;const Field({super.key,required this.icon,required this.color,required this.label,required this.controller});@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.only(bottom:6),child:TextField(controller:controller,decoration:InputDecoration(prefixIcon:Icon(icon,color:color),labelText:label,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none),filled:true,fillColor:const Color(0xFFF8FAFB))));}
class ActionField extends StatelessWidget{final IconData icon;final String label,value;final VoidCallback onTap;const ActionField({super.key,required this.icon,required this.label,required this.value,required this.onTap});@override Widget build(BuildContext c)=>ListTile(onTap:onTap,contentPadding:const EdgeInsets.symmetric(horizontal:4),leading:Icon(icon),title:Text(label,style:const TextStyle(fontSize:12)),subtitle:Text(value,style:const TextStyle(fontWeight:FontWeight.w600)));}
class Popular extends StatelessWidget{final ValueChanged<String> onSelect;const Popular({super.key,required this.onSelect});@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.fromLTRB(16,4,16,16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Destinos populares',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:10),SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:['CDMX, Ciudad de México','Guadalajara, Jalisco','Monterrey, Nuevo León','Tijuana, Baja California'].map((x)=>GestureDetector(onTap:()=>onSelect(x),child:Container(width:145,height:85,margin:const EdgeInsets.only(right:10),decoration:BoxDecoration(borderRadius:BorderRadius.circular(15),gradient:const LinearGradient(colors:[Color(0xFF135B7A),Color(0xFF08A65A)])),alignment:Alignment.bottomLeft,padding:const EdgeInsets.all(9),child:Text(x.split(',').first,style:const TextStyle(color:Colors.white,fontWeight:FontWeight.bold,fontSize:16))))).toList()))]));}
class Safety extends StatelessWidget{const Safety({super.key});@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.fromLTRB(16,0,16,16),child:Card(color:dark,child:ListTile(leading:const Icon(Icons.verified_user,color:Color(0xFF28D97B),size:36),title:const Text('Viajes seguros',style:TextStyle(color:Colors.white,fontWeight:FontWeight.bold)),subtitle:const Text('Verificación, calificaciones y herramientas de seguridad.',style:TextStyle(color:Colors.white70)),trailing:TextButton(onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const SafetyScreen())),child:const Text('Ver')))));
class Benefits extends StatelessWidget{const Benefits({super.key});@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.fromLTRB(12,0,12,20),child:Row(children:const[Expanded(child:Benefit(icon:Icons.directions_car,title:'Publica',text:'Comparte tu ruta')),Expanded(child:Benefit(icon:Icons.savings,title:'Ahorra',text:'Comparte gastos')),Expanded(child:Benefit(icon:Icons.shield,title:'Tranquilo',text:'Verificación')),Expanded(child:Benefit(icon:Icons.people,title:'Conoce',text:'Comunidad'))]));}
class Benefit extends StatelessWidget{final IconData icon;final String title,text;const Benefit({super.key,required this.icon,required this.title,required this.text});@override Widget build(BuildContext c)=>Column(children:[CircleAvatar(backgroundColor:const Color(0xFFE2F6EC),child:Icon(icon,color:green)),const SizedBox(height:5),Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),Text(text,textAlign:TextAlign.center,style:const TextStyle(fontSize:11))]);}

class ResultsScreen extends StatelessWidget{final AppStore store;final String origin,destination;final DateTime date;final int passengers;const ResultsScreen({super.key,required this.store,required this.origin,required this.destination,required this.date,required this.passengers});@override Widget build(BuildContext c){final matches=store.trips.where((t)=>t.origin.toLowerCase().contains(origin.split(',').first.toLowerCase())&&t.destination.toLowerCase().contains(destination.split(',').first.toLowerCase())).toList();return Scaffold(appBar:AppBar(title:const Text('Buscar viajes'),actions:[IconButton(onPressed:(){},icon:const Icon(Icons.tune))]),body:ListView(padding:const EdgeInsets.all(12),children:[Text('$origin → $destination',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Text('${date.day}/${date.month}/${date.year} · $passengers pasajero(s)',style:const TextStyle(color:Colors.black54)),const SizedBox(height:12),if(matches.isEmpty)const Card(child:Padding(padding:EdgeInsets.all(22),child:Text('No encontramos viajes con esos datos todavía. Puedes publicar el tuyo.'))),...matches.map((t)=>TripCard(trip:t,store:store))]));}}
class TripCard extends StatelessWidget{final Trip trip;final AppStore store;const TripCard({super.key,required this.trip,required this.store});@override Widget build(BuildContext c)=>Card(margin:const EdgeInsets.only(bottom:12),child:InkWell(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>TripDetail(trip:trip,store:store))),borderRadius:BorderRadius.circular(16),child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[Row(children:[const CircleAvatar(child:Icon(Icons.person)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(trip.driver,style:const TextStyle(fontWeight:FontWeight.bold)),const Text('★ 4.8 · 128 viajes',style:TextStyle(color:Colors.orange))])),Text(trip.price,style:const TextStyle(color:green,fontWeight:FontWeight.bold,fontSize:19))]),const Divider(),Row(children:[Expanded(child:Text('${trip.time}\n${trip.origin.split(',').first} → ${trip.destination.split(',').first}',style:const TextStyle(fontWeight:FontWeight.w600))),Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text('${trip.seats} asientos'),Text(trip.vehicle,style:const TextStyle(fontSize:12,color:Colors.black54))])])]))));}
class TripDetail extends StatefulWidget {
  final Trip trip;
  final AppStore store;
  const TripDetail({super.key, required this.trip, required this.store});
  @override
  State<TripDetail> createState() => _TripDetailState();
}

class _TripDetailState extends State<TripDetail> {
  bool loading = false;

  Future<void> reserve() async {
    if (widget.store.hasBooking(widget.trip)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Ya tienes una reserva para este viaje.')),
        );
      }
      return;
    }

    if ((int.tryParse(widget.trip.seats) ?? 0) <= 0) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Este viaje ya no tiene asientos disponibles.')),
        );
      }
      return;
    }

    setState(() => loading = true);
    await widget.store.addBooking(widget.trip);
    if (!mounted) return;
    setState(() => loading = false);

    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('¡Reserva confirmada!'),
        content: Text(
          'Tu asiento quedó reservado en conrumbo.\n\n'
          '${widget.trip.origin} → ${widget.trip.destination}\n'
          '${widget.trip.date} · ${widget.trip.time}\n'
          'Aportación: ${widget.trip.price}',
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Listo'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final reserved = widget.store.hasBooking(widget.trip);
    return Scaffold(
      appBar: AppBar(title: const Text('Detalle del viaje')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const CircleAvatar(radius: 34, child: Icon(Icons.person, size: 38)),
          const SizedBox(height: 8),
          Center(
            child: Text(
              '${widget.trip.driver} · ★ 4.8 · Verificado',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
            ),
          ),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${widget.trip.origin} → ${widget.trip.destination}',
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  Text('${widget.trip.date} · ${widget.trip.time}'),
                  Text('${widget.trip.seats} asientos disponibles'),
                  Text(widget.trip.vehicle),
                  const SizedBox(height: 12),
                  const Text('Compartir gastos del viaje', style: TextStyle(fontWeight: FontWeight.bold)),
                  const Text('El monto mostrado corresponde a la aportación por asiento.'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 52,
            child: FilledButton(
              onPressed: loading || reserved ? null : reserve,
              child: Text(reserved ? 'Asiento reservado' : 'Reservar asiento · ${widget.trip.price}'),
            ),
          ),
        ],
      ),
    );
  }
}

class PublishScreen extends StatefulWidget{final AppStore store;const PublishScreen({super.key,required this.store});@override State<PublishScreen> createState()=>_PublishScreenState();}
class _PublishScreenState extends State<PublishScreen>{final o=TextEditingController(text:'Monterrey, Nuevo León'),d=TextEditingController(text:'CDMX, Ciudad de México'),price=TextEditingController(text:'420');int seats=3;String vehicle='Kia K3 · Gris';DateTime date=DateTime(2026,10,5);TimeOfDay time=const TimeOfDay(hour:8,minute:0);Future<void> submit()async{final t=Trip(origin:o.text,destination:d.text,date:'${date.day}/${date.month}/${date.year}',time:time.format(context),price:'\$${price.text}',seats:'$seats',vehicle:vehicle,driver:widget.store.name.isEmpty?'Mi viaje':widget.store.name);await widget.store.addTrip(t);if(!mounted)return;await showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('¡Viaje publicado!'),content:const Text('Tu viaje se guardó en este dispositivo y ya aparece en el buscador.'),actions:[FilledButton(onPressed:()=>Navigator.pop(context),child:const Text('Listo'))]));if(mounted)Navigator.pop(context);} @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Publicar viaje')),body:ListView(padding:const EdgeInsets.all(16),children:[const Text('1 · Ruta',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Field(icon:Icons.location_on,color:green,label:'Origen',controller:o),Field(icon:Icons.location_on,color:Colors.red,label:'Destino',controller:d),const SizedBox(height:12),const Text('2 · Fecha y hora',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),ActionField(icon:Icons.calendar_month,label:'Fecha',value:'${date.day}/${date.month}/${date.year}',onTap:()async{final x=await showDatePicker(context:context,firstDate:DateTime.now(),lastDate:DateTime.now().add(const Duration(days:365)),initialDate:date);if(x!=null)setState(()=>date=x);}),ActionField(icon:Icons.schedule,label:'Hora de salida',value:time.format(context),onTap:()async{final x=await showTimePicker(context:context,initialTime:time);if(x!=null)setState(()=>time=x);}),const SizedBox(height:8),const Text('3 · Asientos y aportación',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),ListTile(title:const Text('Asientos disponibles'),trailing:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(onPressed:seats>1?()=>setState(()=>seats--):null,icon:const Icon(Icons.remove_circle_outline)),Text('$seats'),IconButton(onPressed:seats<7?()=>setState(()=>seats++):null,icon:const Icon(Icons.add_circle_outline))])),TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Aportación por asiento',prefixText:'$ ',border:OutlineInputBorder())),const SizedBox(height:16),const Text('4 · Vehículo',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),DropdownButtonFormField<String>(value:vehicle,items:const['Kia K3 · Gris','Toyota Corolla · Blanco','Mazda 3 · Rojo','Nissan Sentra · Negro'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x)=>setState(()=>vehicle=x!),decoration:const InputDecoration(border:OutlineInputBorder())),const SizedBox(height:24),SizedBox(height:52,child:FilledButton(onPressed:submit,child:const Text('Publicar viaje',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold))))]));}
}

class ProfileScreen extends StatelessWidget {
  final AppStore store;

  const ProfileScreen({super.key, required this.store});

  Future<void> logout(BuildContext context) async {
    await store.logout();
    if (!context.mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => AuthScreen(store: store)),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mi perfil'),
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.settings)),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const CircleAvatar(radius: 45, child: Icon(Icons.person, size: 52)),
          const SizedBox(height: 10),
          Center(
            child: Text(
              store.name.isEmpty ? 'Usuario conrumbo' : store.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ),
          Center(child: Text(store.email)),
          const SizedBox(height: 20),
          Card(
            child: Column(
              children: const [
                ListTile(
                  leading: Icon(Icons.verified_user, color: green),
                  title: Text('Identidad'),
                  trailing: Text('Pendiente'),
                ),
                ListTile(
                  leading: Icon(Icons.drive_eta, color: green),
                  title: Text('Licencia de conducir'),
                  trailing: Text('Pendiente'),
                ),
                ListTile(
                  leading: Icon(Icons.directions_car, color: green),
                  title: Text('Vehículo'),
                  trailing: Text('Agregar'),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.route),
                  title: const Text('Mis viajes'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => MyTripsScreen(store: store),
                      ),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.event_seat, color: green),
                  title: const Text('Mis reservas'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => MyBookingsScreen(store: store),
                      ),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.security),
                  title: const Text('Centro de seguridad'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SafetyScreen()),
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.logout),
                  title: const Text('Cerrar sesión'),
                  onTap: () => logout(context),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class MyTripsScreen extends StatelessWidget {
  final AppStore store;

  const MyTripsScreen({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    final List<Widget> cards = store.trips.map<Widget>((t) {
      return Card(
        child: ListTile(
          leading: const Icon(Icons.route, color: green),
          title: Text(
            '${t.origin.split(',').first} → ${t.destination.split(',').first}',
          ),
          subtitle: Text('${t.date} · ${t.time} · ${t.seats} asientos'),
          trailing: Text(
            t.price,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      );
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Mis viajes')),
      body: cards.isEmpty
          ? const Center(child: Text('Todavía no tienes viajes publicados.'))
          : ListView(padding: const EdgeInsets.all(12), children: cards),
    );
  }
}

class MyBookingsScreen extends StatelessWidget {
  final AppStore store;

  const MyBookingsScreen({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    if (store.bookings.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Mis reservas')),
        body: const Center(child: Text('Todavía no tienes reservas.')),
      );
    }

    final List<Widget> cards = store.bookings.map<Widget>((b) {
      return Card(
        child: ListTile(
          leading: const Icon(Icons.event_seat, color: green),
          title: Text(
            '${b.origin.split(',').first} → ${b.destination.split(',').first}',
          ),
          subtitle: Text(
            '${b.date} · ${b.time}\nConductor: ${b.driver} · ${b.vehicle}',
          ),
          isThreeLine: true,
          trailing: Text(
            b.price,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: green,
            ),
          ),
        ),
      );
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Mis reservas')),
      body: ListView(padding: const EdgeInsets.all(12), children: cards),
    );
  }
}

class SafetyScreen extends StatelessWidget {
  const SafetyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Centro de seguridad')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Card(
            child: ListTile(
              leading: Icon(Icons.verified_user, color: green),
              title: Text('Verificación de identidad'),
              subtitle: Text('Ayuda a crear una comunidad de confianza.'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(Icons.directions_car, color: green),
              title: Text('Vehículos verificados'),
              subtitle: Text('Información del vehículo antes de viajar.'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(Icons.star, color: green),
              title: Text('Calificaciones'),
              subtitle: Text('Consulta las opiniones de otros usuarios.'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(Icons.report_problem, color: green),
              title: Text('Reportar un problema'),
              subtitle: Text('Herramientas de ayuda y seguridad.'),
            ),
          ),
        ],
      ),
    );
  }
}
