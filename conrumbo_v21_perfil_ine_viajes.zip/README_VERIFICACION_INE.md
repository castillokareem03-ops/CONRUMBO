# Verificación de identidad conrumbo

Esta versión cambia la verificación de identidad para que la cuenta no se considere verificada solo por escribir una INE.

## Flujo
1. Al registrarse, el usuario captura una foto de su INE.
2. La foto se guarda en Firebase Storage en `identity_documents/{uid}/ine.jpg`.
3. La cuenta queda con `verificationStatus: pending` y `verified: false`.
4. El administrador entra al Panel de administración > Verificaciones de identidad.
5. El administrador puede revisar la foto y aprobar o rechazar la verificación.
6. Solo una cuenta aprobada puede publicar o reservar viajes.

## Firebase Storage
En Firebase Console hay que habilitar **Storage** para el proyecto CONRUMBO y publicar las reglas incluidas en `storage.rules`.

Las fotos de INE quedan restringidas: el propio usuario puede leer/escribir su archivo y el administrador puede revisarlo.

## Importante
La foto permite una revisión manual, pero por sí sola no demuestra automáticamente que una INE sea auténtica. Para una validación automática de identidad será necesario integrar posteriormente un proveedor especializado de verificación de identidad/OCR.


v21: la foto de INE se solicita desde Mi perfil, no durante reserva/publicación ni durante el registro.
