import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';

class FirebaseService {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore db = FirebaseFirestore.instance;

  User? get currentUser => auth.currentUser;

  Future<String> uploadInePhoto(String uid, String filePath) async {
    if (filePath.trim().isEmpty) throw Exception('Debes seleccionar una foto de tu INE.');
    final file = File(filePath);
    if (!await file.exists()) throw Exception('No se encontró la foto de la INE.');
    final ref = FirebaseStorage.instance.ref().child('identity_documents/$uid/ine.jpg');
    await ref.putFile(file, SettableMetadata(contentType: 'image/jpeg'));
    return ref.getDownloadURL();
  }

  Future<UserCredential> register({required String name, required String email, required String password, required String phone, required int age, required String ine, required String inePhotoPath}) async {
    final credential = await auth.createUserWithEmailAndPassword(email: email, password: password);
    final uid = credential.user!.uid;
    try {
      final inePhotoUrl = await uploadInePhoto(uid, inePhotoPath);
      await db.collection('users').doc(uid).set({
        'uid': uid,
        'name': name,
        'email': email,
        'phone': phone,
        'age': age,
        'ine': ine,
        'inePhotoUrl': inePhotoUrl,
        'verificationStatus': 'pending',
        'verified': false,
        'role': 'user',
        'blocked': false,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return credential;
    } catch (e) {
      try { await credential.user?.delete(); } catch (_) {}
      rethrow;
    }
  }

  Future<UserCredential> login({required String email, required String password}) async {
    final credential = await auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
    await ensureUserProfile(credential.user!);
    return credential;
  }

  Future<void> ensureUserProfile(User user, {String? name, String phone = ''}) async {
    final ref = db.collection('users').doc(user.uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'uid': user.uid,
        'name': (name ?? user.displayName ?? '').trim(),
        'email': user.email ?? '',
        'phone': phone,
        'age': 0,
        'ine': '',
        'inePhotoUrl': '',
        'verificationStatus': 'pending',
        'verified': false,
        'role': 'user',
        'blocked': false,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<void> logout() => auth.signOut();

  Future<String> createTrip(Map<String, dynamic> data) async {
    final totalSeats = int.tryParse('${data['totalSeats'] ?? data['seats'] ?? 0}') ?? 0;
    final ref = await db.collection('trips').add({
      ...data,
      'driverId': currentUser!.uid,
      'status': 'active',
      'totalSeats': totalSeats,
      'availableSeats': totalSeats,
      'seats': '$totalSeats',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<List<Map<String, dynamic>>> getTrips() async {
    final snap = await db.collection('trips').where('status', isEqualTo: 'active').get();
    return snap.docs.map((d) => {'id': d.id, ...d.data()}).toList();
  }

  Future<List<Map<String, dynamic>>> getMyTrips() async {
    final snap = await db.collection('trips').where('driverId', isEqualTo: currentUser!.uid).get();
    return snap.docs.map((d) => {'id': d.id, ...d.data()}).toList();
  }

  Stream<List<Map<String, dynamic>>> myTripsStream() {
    final uid = currentUser?.uid;
    if (uid == null) return const Stream.empty();
    return db.collection('trips')
        .where('driverId', isEqualTo: uid)
        .snapshots()
        .map((snap) => snap.docs.map((d) => {'id': d.id, ...d.data()}).toList());
  }

  Stream<List<Map<String, dynamic>>> tripsStream() => db
      .collection('trips')
      .where('status', isEqualTo: 'active')
      .snapshots()
      .map((snap) => snap.docs.map((d) => {'id': d.id, ...d.data()}).toList());

  Future<int> getCurrentAvailableSeats(String tripId) async {
    if (tripId.isEmpty) return 0;
    final tripSnap = await db.collection('trips').doc(tripId).get();
    if (!tripSnap.exists) return 0;
    final data = tripSnap.data() ?? <String, dynamic>{};
    final total = int.tryParse('${data['totalSeats'] ?? data['seats'] ?? 0}') ?? 0;
    if (total < 1) return 0;

    // Recalcula para corregir viajes de pruebas anteriores que quedaron
    // con availableSeats=0 aunque no tengan reservas activas.
    final bookingSnap = await db.collection('bookings')
        .where('tripId', isEqualTo: tripId)
        .get();
    var booked = 0;
    for (final doc in bookingSnap.docs) {
      final b = doc.data();
      final status = '${b['status'] ?? 'pending'}';
      if (status == 'pending' || status == 'accepted') {
        booked += int.tryParse('${b['seatsRequested'] ?? b['seats'] ?? 1}') ?? 1;
      }
    }
    return (total - booked).clamp(0, total).toInt();
  }

  Future<bool> passengerHasActiveBooking(String tripId) async {
    final uid = currentUser?.uid;
    if (uid == null || tripId.isEmpty) return false;
    final snap = await db.collection('bookings').where('passengerId', isEqualTo: uid).get();
    return snap.docs.any((doc) {
      final d = doc.data();
      return '${d['tripId'] ?? ''}' == tripId &&
          ('${d['status'] ?? 'pending'}' == 'pending' || '${d['status'] ?? ''}' == 'accepted');
    });
  }

  Future<bool> createBooking(Map<String, dynamic> data) async {
    final tripId = '${data['tripId'] ?? ''}';
    final passengerId = '${data['passengerId'] ?? ''}';
    final requested = int.tryParse('${data['seatsRequested'] ?? data['seats'] ?? 1}') ?? 1;
    if (tripId.isEmpty || passengerId.isEmpty || requested < 1) return false;

    final tripRef = db.collection('trips').doc(tripId);
    final bookingRef = db.collection('bookings').doc();
    // Corrige primero viajes de pruebas antiguas que conservaron availableSeats=0.
    await repairTripSeats(tripId);

    return db.runTransaction<bool>((tx) async {
      final tripSnap = await tx.get(tripRef);
      if (!tripSnap.exists) return false;

      // La reserva usa un ID nuevo. La duplicidad se comprueba antes de reservar.
      final tripData = tripSnap.data() ?? <String, dynamic>{};
      final total = int.tryParse('${tripData['totalSeats'] ?? tripData['seats'] ?? 0}') ?? 0;
      if (total < 1) return false;

      final available = int.tryParse('${tripData['availableSeats'] ?? tripData['seats'] ?? 0}') ?? 0;
      if (available < requested) return false;

      tx.update(tripRef, {
        'availableSeats': available - requested,
        'seats': '${available - requested}',
        'updatedAt': FieldValue.serverTimestamp(),
      });
      tx.set(bookingRef, {
        ...data,
        'seatsRequested': requested,
        'seats': '$requested',
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return true;
    });
  }

  Future<void> repairTripSeats(String id) async {
    final tripRef = db.collection('trips').doc(id);
    final tripSnap = await tripRef.get();
    if (!tripSnap.exists) return;
    final trip = tripSnap.data() ?? <String, dynamic>{};
    final total = int.tryParse('${trip['totalSeats'] ?? trip['seats'] ?? 0}') ?? 0;
    if (total < 1) return;

    final bookingSnap = await db.collection('bookings').where('tripId', isEqualTo: id).get();
    var booked = 0;
    for (final doc in bookingSnap.docs) {
      final data = doc.data();
      final status = '${data['status'] ?? 'pending'}';
      if (status == 'pending' || status == 'accepted') {
        booked += int.tryParse('${data['seatsRequested'] ?? data['seats'] ?? 1}') ?? 1;
      }
    }
    final available = (total - booked).clamp(0, total).toInt();
    await tripRef.update({
      'availableSeats': available,
      'seats': '$available',
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> setTripTotalSeats(String id, int totalSeats) async {
    await db.collection('trips').doc(id).update({
      'totalSeats': totalSeats,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> setTripStatus(String id, String status) async {
    if (!['active', 'cancelled', 'completed'].contains(status)) return;
    await db.collection('trips').doc(id).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteTrip(String id) async {
    if (id.isEmpty || currentUser == null) throw Exception('No se encontró el viaje.');
    final ref = db.collection('trips').doc(id);
    final snap = await ref.get();
    if (!snap.exists) throw Exception('El viaje ya no existe.');
    final data = snap.data() ?? <String, dynamic>{};
    if ('${data['driverId'] ?? ''}' != currentUser!.uid) {
      throw Exception('Solo el conductor puede borrar este viaje.');
    }
    final bookings = await db.collection('bookings')
        .where('tripId', isEqualTo: id)
        .get();
    final activeBookings = bookings.docs.where((booking) {
      final status = '${booking.data()['status'] ?? 'pending'}';
      return status == 'pending' || status == 'accepted';
    }).toList();
    if (activeBookings.isNotEmpty) {
      throw Exception('No puedes borrar este viaje mientras tenga reservas pendientes o aceptadas. Cancela/rechaza esas reservas primero.');
    }
    final batch = db.batch();
    batch.delete(ref);
    for (final booking in bookings.docs) {
      batch.delete(booking.reference);
    }
    await batch.commit();
  }

  Future<void> updateTrip(String id, Map<String, dynamic> data) async {
    final totalSeats = int.tryParse('${data['totalSeats'] ?? data['seats'] ?? 0}') ?? 0;
    if (totalSeats < 1) throw Exception('El viaje debe tener al menos 1 asiento.');
    final tripRef = db.collection('trips').doc(id);

    await db.runTransaction((tx) async {
      final tripSnap = await tx.get(tripRef);
      if (!tripSnap.exists) throw Exception('El viaje ya no existe.');
      final current = tripSnap.data() ?? <String, dynamic>{};
      final currentAvailable = int.tryParse('${current['availableSeats'] ?? current['seats'] ?? 0}') ?? 0;
      final currentTotal = int.tryParse('${current['totalSeats'] ?? ''}') ?? currentAvailable;
      final booked = (currentTotal - currentAvailable).clamp(0, currentTotal).toInt();
      if (totalSeats < booked) {
        throw Exception('No puedes reducir los asientos a $totalSeats porque ya hay $booked reservados.');
      }
      final available = totalSeats - booked;
      tx.update(tripRef, {
        ...data,
        'totalSeats': totalSeats,
        'availableSeats': available,
        'seats': '$available',
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myBookings() => db
      .collection('bookings')
      .where('passengerId', isEqualTo: currentUser!.uid)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> driverBookings() => db
      .collection('bookings')
      .where('driverId', isEqualTo: currentUser!.uid)
      .snapshots();

  Future<List<Map<String, dynamic>>> getDriverBookingsOnce() async {
    final snap = await db.collection('bookings').where('driverId', isEqualTo: currentUser!.uid).get();
    return snap.docs.map((d) => {'id': d.id, ...d.data()}).toList();
  }

  Future<void> cancelBooking(String id) async {
    final bookingRef = db.collection('bookings').doc(id);
    await db.runTransaction((tx) async {
      final bookingSnap = await tx.get(bookingRef);
      if (!bookingSnap.exists) throw Exception('La reserva ya no existe.');
      final data = bookingSnap.data() ?? <String, dynamic>{};
      final passengerId = '${data['passengerId'] ?? ''}';
      if (passengerId != currentUser!.uid) throw Exception('No puedes cancelar esta reserva.');
      final status = '${data['status'] ?? 'pending'}';
      if (status == 'cancelled' || status == 'rejected') return;
      final seats = int.tryParse('${data['seatsRequested'] ?? data['seats'] ?? 1}') ?? 1;
      final tripId = '${data['tripId'] ?? ''}';
      if (tripId.isNotEmpty) {
        final tripRef = db.collection('trips').doc(tripId);
        final tripSnap = await tx.get(tripRef);
        if (tripSnap.exists) {
          final trip = tripSnap.data() ?? <String, dynamic>{};
          final available = int.tryParse('${trip['availableSeats'] ?? trip['seats'] ?? 0}') ?? 0;
          tx.update(tripRef, {
            'availableSeats': available + seats,
            'seats': '${available + seats}',
            'updatedAt': FieldValue.serverTimestamp(),
          });
        }
      }
      tx.update(bookingRef, {'status': 'cancelled', 'updatedAt': FieldValue.serverTimestamp()});
    });
  }

  Future<void> driverUpdateBooking(String id, String status) async {
    if (status != 'accepted' && status != 'rejected') return;
    final bookingRef = db.collection('bookings').doc(id);
    await db.runTransaction((tx) async {
      final bookingSnap = await tx.get(bookingRef);
      if (!bookingSnap.exists) throw Exception('La reserva ya no existe.');
      final data = bookingSnap.data() ?? <String, dynamic>{};
      if ('${data['driverId'] ?? ''}' != currentUser!.uid) throw Exception('No puedes modificar esta reserva.');
      if ('${data['status'] ?? 'pending'}' != 'pending') return;
      if (status == 'rejected') {
        final seats = int.tryParse('${data['seatsRequested'] ?? data['seats'] ?? 1}') ?? 1;
        final tripId = '${data['tripId'] ?? ''}';
        if (tripId.isNotEmpty) {
          final tripRef = db.collection('trips').doc(tripId);
          final tripSnap = await tx.get(tripRef);
          if (tripSnap.exists) {
            final trip = tripSnap.data() ?? <String, dynamic>{};
            final available = int.tryParse('${trip['availableSeats'] ?? trip['seats'] ?? 0}') ?? 0;
            tx.update(tripRef, {
              'availableSeats': available + seats,
              'seats': '${available + seats}',
              'updatedAt': FieldValue.serverTimestamp(),
            });
          }
        }
      }
      tx.update(bookingRef, {'status': status, 'updatedAt': FieldValue.serverTimestamp()});
    });
  }

  Future<void> updateBooking(String id, String status) => driverUpdateBooking(id, status);

  Stream<DocumentSnapshot<Map<String, dynamic>>> userStream(String uid) =>
      db.collection('users').doc(uid).snapshots();

  Future<Map<String, dynamic>> getUserProfile(String uid) async {
    final snap = await db.collection('users').doc(uid).get();
    return snap.data() ?? <String, dynamic>{};
  }

  Future<void> updateProfile(String uid, Map<String, dynamic> data) async {
    final safe = Map<String, dynamic>.from(data)
      ..remove('role')
      ..remove('blocked')
      ..remove('uid')
      ..remove('createdAt');
    safe['updatedAt'] = FieldValue.serverTimestamp();
    await db.collection('users').doc(uid).update(safe);
  }

  Future<String> getRole(String uid) async {
    final data = await getUserProfile(uid);
    return '${data['role'] ?? 'user'}';
  }

  Future<void> report({required String reportedUserId, required String reason, String? tripId, String? details}) async {
    await db.collection('reports').add({
      'reporterId': currentUser!.uid,
      'reportedUserId': reportedUserId,
      'reason': reason,
      'details': details ?? '',
      'tripId': tripId ?? '',
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> createSupportTicket({required String subject, required String message}) async {
    await db.collection('supportTickets').add({
      'userId': currentUser!.uid,
      'userEmail': currentUser!.email ?? '',
      'subject': subject,
      'message': message,
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> mySupportTickets() => db
      .collection('supportTickets')
      .where('userId', isEqualTo: currentUser!.uid)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> adminReports() => db
      .collection('reports')
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> adminTickets() => db
      .collection('supportTickets')
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> adminUsers() => db
      .collection('users')
      .snapshots();

  Future<void> adminSetVerification(String uid, {required bool approved, String reason = ''}) async {
    await db.collection('users').doc(uid).update({
      'verified': approved,
      'verificationStatus': approved ? 'approved' : 'rejected',
      if (reason.trim().isNotEmpty) 'verificationNote': reason.trim(),
      'verifiedAt': FieldValue.serverTimestamp(),
      'verifiedBy': currentUser?.uid ?? '',
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminLogAction({required String action, required String targetUserId, String details = ''}) async {
    await db.collection('adminActions').add({
      'adminId': currentUser!.uid,
      'action': action,
      'targetUserId': targetUserId,
      'details': details,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminSetBlocked(String uid, bool blocked) async {
    await db.collection('users').doc(uid).update({
      'blocked': blocked,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminUpdateReport(String id, String status) async {
    await db.collection('reports').doc(id).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminDeleteReport(String id) async {
    final ref = db.collection('reports').doc(id);
    try {
      await ref.delete();
    } catch (_) {
      await ref.update({'status': 'deleted', 'deletedAt': FieldValue.serverTimestamp(), 'updatedAt': FieldValue.serverTimestamp()});
    }
  }

  Future<void> adminDeleteTicket(String id) async {
    final ref = db.collection('supportTickets').doc(id);
    try {
      await ref.delete();
    } catch (_) {
      await ref.update({'status': 'deleted', 'deletedAt': FieldValue.serverTimestamp(), 'updatedAt': FieldValue.serverTimestamp()});
    }
  }

  Future<void> adminReplyTicket(String id, String reply, String status) async {
    await db.collection('supportTickets').doc(id).update({
      'adminReply': reply,
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}
