# conrumbo — MVP 5 (100% gratuito para desarrollo)

Aplicación Flutter para compartir viajes y gastos entre usuarios.

## Incluye
- Registro/inicio de sesión local para pruebas.
- Publicación de viajes.
- Búsqueda de viajes.
- Control de asientos disponibles.
- Reserva de asiento dentro de la app.
- Prevención de doble reserva del mismo viaje desde el mismo dispositivo.
- Pantalla “Mis reservas”.
- Perfil y centro de seguridad.
- Persistencia local con SharedPreferences.

## Importante
Esta versión es un MVP gratuito y local: los datos todavía viven en el teléfono donde se ejecuta la app. No hay pagos ni cargos.

## Para convertirla en multiusuario
El siguiente paso es conectar Firebase en su plan gratuito (Spark), usando Authentication + Firestore. No se deben inventar credenciales: la configuración se genera desde el proyecto Firebase del propietario.

## Ejecutar
Se necesita Flutter instalado. Dentro del proyecto:

```bash
flutter pub get
flutter run
```

## Android
Para generar APK:

```bash
flutter build apk --release
```
