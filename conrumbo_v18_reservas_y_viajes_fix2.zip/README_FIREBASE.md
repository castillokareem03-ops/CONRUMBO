# conrumbo MVP v4 — Firebase

Esta versión está preparada para conectar Firebase. La configuración específica de Firebase no se incluye porque pertenece al proyecto del propietario.

## 1. Instalar herramientas

Instala Flutter y Firebase CLI. Después:

```bash
firebase login
dart pub global activate flutterfire_cli
```

## 2. Crear el proyecto

En Firebase Console crea un proyecto llamado `conrumbo` (o el nombre disponible que prefieras).

## 3. Desde esta carpeta

```bash
flutter pub add firebase_core firebase_auth cloud_firestore
flutterfire configure
```

Selecciona **Android**. `flutterfire configure` generará `lib/firebase_options.dart` y configurará la aplicación Android.

## 4. Activar autenticación

Firebase Console → Authentication → Sign-in method → Email/Password → Enable.

## 5. Crear Firestore

Firebase Console → Firestore Database → Create database.

Para desarrollo inicial puedes usar reglas de prueba temporalmente, pero antes de publicar hay que reemplazarlas por reglas de producción.

## 6. Colecciones previstas

- `users/{uid}`
- `vehicles/{vehicleId}`
- `trips/{tripId}`
- `bookings/{bookingId}`
- `reviews/{reviewId}`
- `reports/{reportId}`

## 7. Próximo desarrollo

Después de generar `firebase_options.dart`, la app se puede conectar para:

- registro/login real
- perfiles en Firestore
- publicar viajes en la nube
- búsqueda de viajes de otros usuarios
- reservas
- reglas de seguridad por usuario

No subas claves privadas ni credenciales de administrador al proyecto Flutter.
