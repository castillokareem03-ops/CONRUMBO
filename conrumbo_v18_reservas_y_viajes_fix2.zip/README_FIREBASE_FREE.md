# Próximo paso: Firebase gratuito

Para que una persona publique un viaje y otra persona lo encuentre desde otro teléfono, hay que pasar de almacenamiento local a nube.

La opción prevista es Firebase en el plan Spark, empezando con Authentication y Cloud Firestore.

1. Crear un proyecto en Firebase.
2. Activar Authentication > Email/Password.
3. Crear Firestore Database.
4. En el proyecto Flutter ejecutar:
   `dart pub global activate flutterfire_cli`
5. Ejecutar:
   `flutterfire configure`
6. Agregar:
   `flutter pub add firebase_core firebase_auth cloud_firestore`

Después se implementarán usuarios, viajes y reservas en Firestore. Los límites gratuitos dependen de las cuotas vigentes de Firebase.
