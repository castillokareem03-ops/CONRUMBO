# CONRUMBO v13 — Firebase real

Esta versión conecta el registro, inicio de sesión y perfil con Firebase Authentication y Cloud Firestore.

## Antes de compilar
- En Firebase Authentication, habilitar Email/Password.
- Crear Firestore en `northamerica-south1 (Mexico)`.
- Descargar `google-services.json` y colocarlo mediante Codemagic en `android/app/google-services.json`.

## Primer administrador
1. Instala y abre la app.
2. Crea una cuenta normal.
3. En Firebase Console > Firestore > users, abre el documento cuyo ID sea el UID de esa cuenta.
4. Cambia únicamente `role` de `user` a `admin`.
5. No cambies `uid` ni `blocked`.

El campo `role` no puede ser cambiado por un usuario desde la app. Las reglas de Firestore permiten acciones administrativas solo cuando el documento del usuario tiene `role == admin`.

## Importante
Para producción conviene migrar el rol de administrador a Firebase Auth Custom Claims mediante un backend seguro. Esta versión deja el rol protegido en Firestore para que podamos probar el flujo sin servidor adicional.
