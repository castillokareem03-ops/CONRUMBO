# conrumbo v16 — seguridad, reportes y soporte conectados

Esta versión mantiene el panel de administración de v15 y conecta las acciones principales con Firebase/Firestore.

Incluye:
- Reportar un problema desde Centro de seguridad.
- Crear reportes reales en `reports`.
- Ayuda y soporte para crear tickets reales en `supportTickets`.
- Consulta de solicitudes propias y respuestas del administrador.
- Panel admin para usuarios, reportes y soporte.
- Bloqueo/desbloqueo de usuarios y registro de acciones.
- Resolución de reportes.
- Respuesta de soporte.
- Se eliminaron `orderBy` innecesarios para reducir errores por índices de Firestore.
