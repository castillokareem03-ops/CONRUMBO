import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_service.dart' as app_firebase;

const Color green = Color(0xFF08A65A);
const Color dark = Color(0xFF06354A);
const Color bg = Color(0xFFF7F9FA);

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  final store = AppStore();
  await store.load();
  runApp(ConRumboApp(store: store));
}

class ConRumboApp extends StatelessWidget {
  final AppStore store;

  const ConRumboApp({Key? key, required this.store}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'conrumbo',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        scaffoldBackgroundColor: bg,
      ),
      home: store.loggedIn
          ? (store.verified ? HomeScreen(store: store) : VerificationScreen(store: store))
          : AuthScreen(store: store),
    );
  }
}

class Trip {
  String id;
  String driverId;
  String origin;
  String destination;
  String date;
  String time;
  String price;
  String seats;
  String totalSeats;
  String vehicle;
  String driver;
  String driverPhone;
  String status;

  Trip({
    this.id = '',
    this.driverId = '',
    required this.origin,
    required this.destination,
    required this.date,
    required this.time,
    required this.price,
    required this.seats,
    this.totalSeats = '0',
    required this.vehicle,
    this.driver = 'Carlos M.',
    this.driverPhone = '',
    this.status = 'active',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'driverId': driverId,
        'origin': origin,
        'destination': destination,
        'date': date,
        'time': time,
        'price': price,
        'seats': seats,
        'totalSeats': totalSeats == '0' ? seats : totalSeats,
        'vehicle': vehicle,
        'driver': driver,
        'driverPhone': driverPhone,
        'status': status,
      };

  factory Trip.fromJson(Map<String, dynamic> json) {
    return Trip(
      id: '${json['id'] ?? ''}',
      driverId: '${json['driverId'] ?? ''}',
      origin: '${json['origin'] ?? ''}',
      destination: '${json['destination'] ?? ''}',
      date: '${json['date'] ?? ''}',
      time: '${json['time'] ?? ''}',
      price: '${json['price'] ?? ''}',
      seats: '${json['availableSeats'] ?? json['seats'] ?? '0'}',
      totalSeats: '${json['totalSeats'] ?? json['seats'] ?? '0'}',
      vehicle: '${json['vehicle'] ?? ''}',
      driver: '${json['driver'] ?? 'Carlos M.'}',
      driverPhone: '${json['driverPhone'] ?? ''}',
      status: '${json['status'] ?? 'active'}',
    );
  }
}

class Booking {
  String id;
  String tripId;
  String tripKey;
  String origin;
  String destination;
  String date;
  String time;
  String price;
  String seats;
  String vehicle;
  String driver;
  String passenger;
  String passengerPhone;
  String driverPhone;
  String status;

  Booking({
    this.id = '',
    this.tripId = '',
    required this.tripKey,
    required this.origin,
    required this.destination,
    required this.date,
    required this.time,
    required this.price,
    required this.seats,
    required this.vehicle,
    required this.driver,
    required this.passenger,
    this.passengerPhone = '',
    this.driverPhone = '',
    this.status = 'pending',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'tripId': tripId,
        'tripKey': tripKey,
        'origin': origin,
        'destination': destination,
        'date': date,
        'time': time,
        'price': price,
        'seats': seats,
        'vehicle': vehicle,
        'driver': driver,
        'passenger': passenger,
        'passengerPhone': passengerPhone,
        'driverPhone': driverPhone,
        'status': status,
      };

  factory Booking.fromJson(Map<String, dynamic> json) {
    return Booking(
      id: '${json['id'] ?? ''}',
      tripId: '${json['tripId'] ?? ''}',
      tripKey: '${json['tripKey'] ?? ''}',
      origin: '${json['origin'] ?? ''}',
      destination: '${json['destination'] ?? ''}',
      date: '${json['date'] ?? ''}',
      time: '${json['time'] ?? ''}',
      price: '${json['price'] ?? ''}',
      seats: '${json['seats'] ?? '1'}',
      vehicle: '${json['vehicle'] ?? ''}',
      driver: '${json['driver'] ?? ''}',
      passenger: '${json['passenger'] ?? ''}',
      passengerPhone: '${json['passengerPhone'] ?? ''}',
      driverPhone: '${json['driverPhone'] ?? ''}',
      status: '${json['status'] ?? 'pending'}',
    );
  }
}

class AppStore {
  late SharedPreferences prefs;
  bool loggedIn = false;
  String name = '';
  String email = '';
  String phone = '';
  String identity = '';
  String license = '';
  String vehicleDetails = '';
  int age = 0;
  String ine = '';
  bool verified = false;
  String role = 'user';
  bool blocked = false;
  final app_firebase.FirebaseService firebase = app_firebase.FirebaseService();
  List<Trip> trips = [];
  List<Booking> bookings = [];

  Future<void> load() async {
    prefs = await SharedPreferences.getInstance();
    final firebaseUser = firebase.currentUser;
    loggedIn = firebaseUser != null;
    if (firebaseUser != null) {
      email = firebaseUser.email ?? '';
      try {
        final profile = await firebase.getUserProfile(firebaseUser.uid);
        name = '${profile['name'] ?? firebaseUser.displayName ?? ''}';
        phone = '${profile['phone'] ?? ''}';
        identity = '${profile['identity'] ?? ''}';
        license = '${profile['license'] ?? ''}';
        vehicleDetails = '${profile['vehicleDetails'] ?? ''}';
        age = int.tryParse('${profile['age'] ?? 0}') ?? 0;
        ine = '${profile['ine'] ?? ''}';
        verified = profile['verified'] == true || (name.trim().isNotEmpty && age > 0 && ine.trim().isNotEmpty);
        role = '${profile['role'] ?? 'user'}';
        blocked = profile['blocked'] == true;
        if (blocked) {
          await firebase.logout();
          loggedIn = false;
          return;
        }
        await prefs.setBool('loggedIn', true);
        await prefs.setString('name', name);
        await prefs.setString('email', email);
      } catch (_) {
        loggedIn = false;
      }
    } else {
      loggedIn = false;
    }
    name = prefs.getString('name') ?? '';
    email = prefs.getString('email') ?? '';
    phone = prefs.getString('phone') ?? '';
    identity = prefs.getString('identity') ?? '';
    license = prefs.getString('license') ?? '';
    vehicleDetails = prefs.getString('vehicleDetails') ?? '';
    age = prefs.getInt('age') ?? age;
    ine = prefs.getString('ine') ?? ine;
    verified = verified || (name.trim().isNotEmpty && age > 0 && ine.trim().isNotEmpty);

    final tripData = prefs.getString('trips');
    if (tripData != null) {
      final decoded = jsonDecode(tripData) as List<dynamic>;
      trips = decoded
          .map((item) => Trip.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    }

    if (loggedIn) {
      try {
        final activeTrips = (await firebase.getTrips()).map((item) => Trip.fromJson(item)).toList();
        final ownTrips = await firebase.getMyTrips();
        final byId = <String, Trip>{};
        for (final item in activeTrips) { byId[item.id] = item; }
        for (final item in ownTrips) { final t = Trip.fromJson(item); byId[t.id] = t; }
        trips = byId.values.toList();
        // Repara viajes antiguos: total de asientos menos reservas activas/pendientes.
        for (final trip in trips.where((t) => t.driverId == firebase.currentUser?.uid)) {
          try { await firebase.repairTripSeats(trip.id); } catch (_) {}
        }
        // Vuelve a leer para que la interfaz muestre los asientos ya reparados.
        final refreshed = <String, Trip>{};
        for (final item in (await firebase.getTrips()).map((item) => Trip.fromJson(item))) { refreshed[item.id] = item; }
        for (final item in (await firebase.getMyTrips()).map((item) => Trip.fromJson(item))) { refreshed[item.id] = item; }
        trips = refreshed.values.toList();
      } catch (_) {}
    }

    final bookingData = prefs.getString('bookings');
    if (bookingData != null) {
      final decoded = jsonDecode(bookingData) as List<dynamic>;
      bookings = decoded
          .map((item) => Booking.fromJson(Map<String, dynamic>.from(item)))
          .toList();
    }
  }

  Future<void> register({required String userName, required String userEmail, required String password, String userPhone = '', required int userAge, required String userIne}) async {
    final credential = await firebase.register(name: userName, email: userEmail, password: password, phone: userPhone, age: userAge, ine: userIne);
    loggedIn = true;
    name = userName;
    email = credential.user?.email ?? userEmail;
    phone = userPhone;
    age = userAge;
    ine = userIne;
    verified = true;
    role = 'user';
    blocked = false;
    await prefs.setBool('loggedIn', true);
    await prefs.setString('name', name);
    await prefs.setString('email', email);
    await prefs.setInt('age', age);
    await prefs.setString('ine', ine);
  }

  Future<void> loginWithPassword({required String userEmail, required String password}) async {
    final credential = await firebase.login(email: userEmail, password: password);
    final uid = credential.user!.uid;
    await firebase.ensureUserProfile(credential.user!);
    final profile = await firebase.getUserProfile(uid);
    blocked = profile['blocked'] == true;
    if (blocked) {
      await firebase.logout();
      throw FirebaseAuthException(code: 'user-blocked', message: 'Tu cuenta está bloqueada. Contacta a soporte.');
    }
    loggedIn = true;
    email = credential.user?.email ?? userEmail;
    name = '${profile['name'] ?? 'Usuario conrumbo'}';
    phone = '${profile['phone'] ?? ''}';
    identity = '${profile['identity'] ?? ''}';
    license = '${profile['license'] ?? ''}';
    vehicleDetails = '${profile['vehicleDetails'] ?? ''}';
    age = int.tryParse('${profile['age'] ?? 0}') ?? 0;
    ine = '${profile['ine'] ?? ''}';
    verified = profile['verified'] == true || (name.trim().isNotEmpty && age > 0 && ine.trim().isNotEmpty);
    role = '${profile['role'] ?? 'user'}';
    await prefs.setBool('loggedIn', true);
    await prefs.setString('name', name);
    await prefs.setString('email', email);
    await prefs.setInt('age', age);
    await prefs.setString('ine', ine);
  }

  Future<void> updateProfile({String? newName, String? newPhone, String? newIdentity, String? newLicense, String? newVehicle, int? newAge, String? newIne}) async {
    if (newName != null) { name = newName; await prefs.setString('name', name); }
    if (newPhone != null) { phone = newPhone; await prefs.setString('phone', phone); }
    if (newIdentity != null) { identity = newIdentity; await prefs.setString('identity', identity); }
    if (newLicense != null) { license = newLicense; await prefs.setString('license', license); }
    if (newVehicle != null) { vehicleDetails = newVehicle; await prefs.setString('vehicleDetails', vehicleDetails); }
    if (newAge != null) { age = newAge; await prefs.setInt('age', age); }
    if (newIne != null) { ine = newIne; await prefs.setString('ine', ine); }
    verified = name.trim().isNotEmpty && age > 0 && ine.trim().isNotEmpty;
    final uid = firebase.currentUser?.uid;
    if (uid != null) {
      await firebase.updateProfile(uid, {
        if (newName != null) 'name': name,
        if (newPhone != null) 'phone': phone,
        if (newIdentity != null) 'identity': identity,
        if (newLicense != null) 'license': license,
        if (newVehicle != null) 'vehicleDetails': vehicleDetails,
        if (newAge != null) 'age': age,
        if (newIne != null) 'ine': ine,
        'verified': verified,
      });
    }
  }

  Future<void> updateTrip(Trip trip) async {
    await firebase.updateTrip(trip.id, trip.toJson());
    try {
      final fresh = (await firebase.getTrips()).map((item) => Trip.fromJson(item)).where((item) => item.id == trip.id).toList();
      final index = trips.indexWhere((item) => item.id == trip.id);
      if (index >= 0 && fresh.isNotEmpty) trips[index] = fresh.first;
    } catch (_) {}
    await addTripListSave();
  }

  Future<void> changeTripStatus(Trip trip, String status) async {
    await firebase.setTripStatus(trip.id, status);
    trip.status = status;
    await addTripListSave();
  }

  Future<void> deleteTrip(Trip trip) async {
    await firebase.deleteTrip(trip.id);
    trips.removeWhere((item) => item.id == trip.id);
    await addTripListSave();
  }

  Future<void> logout() async {
    await firebase.logout();
    loggedIn = false;
    role = 'user';
    blocked = false;
    await prefs.setBool('loggedIn', false);
  }

  Future<void> addTrip(Trip trip) async {
    final uid = firebase.currentUser?.uid;
    if (uid == null) throw Exception('Debes iniciar sesión para publicar un viaje.');
    trip.driverId = uid;
    trip.status = 'active';
    trip.id = await firebase.createTrip(trip.toJson());
    trips.insert(0, trip);
    await prefs.setString(
      'trips',
      jsonEncode(trips.map((item) => item.toJson()).toList()),
    );
  }

  Future<void> saveBookings() async {
    await prefs.setString(
      'bookings',
      jsonEncode(bookings.map((item) => item.toJson()).toList()),
    );
  }

  String tripKey(Trip trip) {
    return '${trip.origin}|${trip.destination}|${trip.date}|${trip.time}|${trip.driver}|${trip.vehicle}';
  }

  bool hasBooking(Trip trip) {
    return bookings.any((booking) => booking.tripKey == tripKey(trip) && (booking.status == 'pending' || booking.status == 'accepted'));
  }

  Future<bool> addBooking(Trip trip, int seatsRequested) async {
    if (hasBooking(trip)) return false;
    if (seatsRequested < 1 || trip.id.isEmpty) return false;
    final uid = firebase.currentUser?.uid;
    if (uid == null) return false;

    final created = await firebase.createBooking({
      'tripId': trip.id,
      'passengerId': uid,
      'driverId': trip.driverId,
      'origin': trip.origin,
      'destination': trip.destination,
      'date': trip.date,
      'time': trip.time,
      'price': trip.price,
      'vehicle': trip.vehicle,
      'driver': trip.driver,
      'passenger': name.isEmpty ? 'Usuario conrumbo' : name,
      'passengerPhone': phone,
      'driverPhone': trip.driverPhone,
      'seatsRequested': seatsRequested,
      'status': 'pending',
    });
    if (!created) return false;

    final availableNow = await firebase.getCurrentAvailableSeats(trip.id);
    trip.seats = '$availableNow';
    bookings.insert(0, Booking(
      tripId: trip.id,
      tripKey: tripKey(trip), origin: trip.origin, destination: trip.destination,
      date: trip.date, time: trip.time, price: trip.price, seats: '$seatsRequested',
      vehicle: trip.vehicle, driver: trip.driver, passenger: name.isEmpty ? 'Usuario conrumbo' : name,
      passengerPhone: phone, driverPhone: trip.driverPhone, status: 'pending',
    ));
    await saveBookings();
    return true;
  }

  Future<void> addTripListSave() async {
    await prefs.setString(
      'trips',
      jsonEncode(trips.map((item) => item.toJson()).toList()),
    );
  }
}

class AuthScreen extends StatefulWidget {
  final AppStore store;

  const AuthScreen({Key? key, required this.store}) : super(key: key);

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = false;
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final ageController = TextEditingController();
  final ineController = TextEditingController();

  Future<void> submit() async {
    final email = emailController.text.trim();
    final password = passwordController.text;
    final name = nameController.text.trim();
    final age = int.tryParse(ageController.text.trim()) ?? 0;
    final ine = ineController.text.trim();

    if (email.isEmpty || password.length < 6 || (register && (name.isEmpty || age <= 0 || ine.isEmpty))) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Usa un correo válido y una contraseña de al menos 6 caracteres.')),
      );
      return;
    }

    try {
      if (register) {
        await widget.store.register(userName: name, userEmail: email, password: password, userAge: age, userIne: ine);
      } else {
        await widget.store.loginWithPassword(userEmail: email, password: password);
      }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => widget.store.verified ? HomeScreen(store: widget.store) : VerificationScreen(store: widget.store)));
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      final message = e.code == 'email-already-in-use'
          ? 'Ese correo ya tiene una cuenta.'
          : e.code == 'invalid-credential' || e.code == 'wrong-password'
              ? 'Correo o contraseña incorrectos.'
              : e.code == 'user-blocked'
                  ? (e.message ?? 'Tu cuenta está bloqueada. Contacta a soporte.')
                  : (e.message ?? 'No se pudo completar la operación.');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Icon(Icons.alt_route, color: green, size: 72),
                const SizedBox(height: 8),
                const Text(
                  'conrumbo',
                  style: TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.w900,
                    color: dark,
                  ),
                ),
                const Text('Comparte el camino, llega más lejos.'),
                const SizedBox(height: 35),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Text(
                          register ? 'Crear cuenta' : 'Iniciar sesión',
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 18),
                        if (register)
                          TextField(
                            controller: nameController,
                            decoration: const InputDecoration(
                              labelText: 'Nombre completo',
                              prefixIcon: Icon(Icons.person),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        if (register) const SizedBox(height: 12),
                        if (register)
                          TextField(
                            controller: ageController,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Edad',
                              prefixIcon: Icon(Icons.cake),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        if (register) const SizedBox(height: 12),
                        if (register)
                          TextField(
                            controller: ineController,
                            decoration: const InputDecoration(
                              labelText: 'INE',
                              prefixIcon: Icon(Icons.badge),
                              border: OutlineInputBorder(),
                            ),
                          ),
                        if (register) const SizedBox(height: 12),
                        TextField(
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            labelText: 'Correo electrónico',
                            prefixIcon: Icon(Icons.email),
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: passwordController,
                          obscureText: true,
                          decoration: const InputDecoration(
                            labelText: 'Contraseña',
                            prefixIcon: Icon(Icons.lock),
                            border: OutlineInputBorder(),
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: FilledButton(
                            onPressed: submit,
                            child: Text(register ? 'Crear cuenta' : 'Entrar'),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextButton(
                          onPressed: () => setState(() => register = !register),
                          child: Text(
                            register
                                ? 'Ya tengo una cuenta'
                                : 'Crear una cuenta',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text('Versión MVP · datos de prueba'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class VerificationScreen extends StatefulWidget {
  final AppStore store;
  const VerificationScreen({Key? key, required this.store}) : super(key: key);

  @override
  State<VerificationScreen> createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  late final TextEditingController name;
  late final TextEditingController age;
  late final TextEditingController ine;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    name = TextEditingController(text: widget.store.name);
    age = TextEditingController(text: widget.store.age > 0 ? '${widget.store.age}' : '');
    ine = TextEditingController(text: widget.store.ine);
  }

  Future<void> save() async {
    final n = name.text.trim();
    final a = int.tryParse(age.text.trim()) ?? 0;
    final i = ine.text.trim();
    if (n.isEmpty || a <= 0 || i.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Nombre, edad e INE son obligatorios para usar conrumbo.')));
      return;
    }
    setState(() => saving = true);
    try {
      await widget.store.updateProfile(newName: n, newAge: a, newIne: i);
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => HomeScreen(store: widget.store)), (_) => false);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo guardar la verificación: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Verificación obligatoria')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Icon(Icons.verified_user, color: green, size: 64),
        const SizedBox(height: 12),
        const Text('Antes de publicar o reservar un viaje necesitamos completar tus datos de verificación.', textAlign: TextAlign.center, style: TextStyle(fontSize: 17)),
        const SizedBox(height: 24),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre completo *', border: OutlineInputBorder(), prefixIcon: Icon(Icons.person))),
        const SizedBox(height: 12),
        TextField(controller: age, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Edad *', border: OutlineInputBorder(), prefixIcon: Icon(Icons.cake))),
        const SizedBox(height: 12),
        TextField(controller: ine, decoration: const InputDecoration(labelText: 'INE *', border: OutlineInputBorder(), prefixIcon: Icon(Icons.badge))),
        const SizedBox(height: 20),
        SizedBox(height: 52, child: FilledButton(onPressed: saving ? null : save, child: saving ? const CircularProgressIndicator() : const Text('Guardar y continuar'))),
      ]),
    );
  }

  @override
  void dispose() {
    name.dispose(); age.dispose(); ine.dispose(); super.dispose();
  }
}

class HomeScreen extends StatefulWidget {
  final AppStore store;

  const HomeScreen({Key? key, required this.store}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  final originController = TextEditingController(text: 'Monterrey, Nuevo León');
  final destinationController =
      TextEditingController(text: 'CDMX, Ciudad de México');
  DateTime date = DateTime(2026, 10, 5);
  int passengers = 1;

  void search() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ResultsScreen(
          store: widget.store,
          origin: originController.text,
          destination: destinationController.text,
          date: date,
          passengers: passengers,
        ),
      ),
    );
  }

  void publish() {
    if (!widget.store.verified) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => VerificationScreen(store: widget.store)));
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PublishScreen(store: widget.store)),
    );
  }

  void profile() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => ProfileScreen(store: widget.store)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            const SliverToBoxAdapter(child: HeroHeader()),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: SearchCard(
                  origin: originController,
                  destination: destinationController,
                  date: date,
                  passengers: passengers,
                  onDate: (value) => setState(() => date = value),
                  onPassengers: (value) => setState(() => passengers = value),
                  onSearch: search,
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Popular(
                onSelect: (value) {
                  destinationController.text = value;
                  setState(() {});
                },
              ),
            ),
            SliverToBoxAdapter(child: SafetyCard(store: widget.store)),
            const SliverToBoxAdapter(child: Benefits()),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (index) {
          setState(() => tab = index);
          if (index == 1) search();
          if (index == 2) publish();
          if (index == 3) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => MyBookingsScreen(store: widget.store),
              ),
            );
          }
          if (index == 4) profile();
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Inicio',
          ),
          NavigationDestination(icon: Icon(Icons.search), label: 'Buscar'),
          NavigationDestination(
            icon: Icon(Icons.add_circle_outline),
            selectedIcon: Icon(Icons.add_circle),
            label: 'Publicar',
          ),
          NavigationDestination(
            icon: Icon(Icons.event_seat),
            label: 'Reservas',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }
}

class HeroHeader extends StatelessWidget {
  const HeroHeader({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [dark, Color(0xFF087A57)]),
      ),
      child: Stack(
        children: [
          const Positioned(
            left: 20,
            top: 18,
            child: Icon(Icons.menu, color: Colors.white, size: 30),
          ),
          const Positioned(
            right: 20,
            top: 18,
            child: Icon(
              Icons.notifications_none,
              color: Colors.white,
              size: 29,
            ),
          ),
          Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Icon(Icons.alt_route, color: Color(0xFF28D97B), size: 44),
                    SizedBox(width: 5),
                    Text(
                      'con',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 40,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      'rumbo',
                      style: TextStyle(
                        color: Color(0xFF28D97B),
                        fontSize: 40,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Comparte el camino,\nllega más lejos',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class SearchCard extends StatelessWidget {
  final TextEditingController origin;
  final TextEditingController destination;
  final DateTime date;
  final int passengers;
  final ValueChanged<DateTime> onDate;
  final ValueChanged<int> onPassengers;
  final VoidCallback onSearch;

  const SearchCard({
    Key? key,
    required this.origin,
    required this.destination,
    required this.date,
    required this.passengers,
    required this.onDate,
    required this.onPassengers,
    required this.onSearch,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Field(
              icon: Icons.location_on,
              color: green,
              label: 'Desde',
              controller: origin,
            ),
            Field(
              icon: Icons.location_on,
              color: Colors.redAccent,
              label: 'Hasta',
              controller: destination,
            ),
            ActionField(
              icon: Icons.calendar_month,
              label: 'Fecha de salida',
              value: '${date.day}/${date.month}/${date.year}',
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                  initialDate: date.isBefore(DateTime.now())
                      ? DateTime.now()
                      : date,
                );
                if (picked != null) onDate(picked);
              },
            ),
            ActionField(
              icon: Icons.person_outline,
              label: 'Pasajeros',
              value:
                  '$passengers ${passengers == 1 ? 'pasajero' : 'pasajeros'}',
              onTap: () async {
                int value = passengers;
                await showDialog<void>(
                  context: context,
                  builder: (dialogContext) {
                    return StatefulBuilder(
                      builder: (context, setDialogState) {
                        return AlertDialog(
                          title: const Text('Pasajeros'),
                          content: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              IconButton(
                                onPressed: value > 1
                                    ? () => setDialogState(() => value--)
                                    : null,
                                icon: const Icon(
                                  Icons.remove_circle_outline,
                                ),
                              ),
                              Text(
                                '$value',
                                style: const TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              IconButton(
                                onPressed: value < 6
                                    ? () => setDialogState(() => value++)
                                    : null,
                                icon: const Icon(Icons.add_circle_outline),
                              ),
                            ],
                          ),
                          actions: [
                            FilledButton(
                              onPressed: () {
                                onPassengers(value);
                                Navigator.pop(dialogContext);
                              },
                              child: const Text('Guardar'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: FilledButton.icon(
                onPressed: onSearch,
                icon: const Icon(Icons.search),
                label: const Text(
                  'Buscar viajes',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Field extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final TextEditingController controller;

  const Field({
    Key? key,
    required this.icon,
    required this.color,
    required this.label,
    required this.controller,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: color),
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: const Color(0xFFF8FAFB),
        ),
      ),
    );
  }
}

class ActionField extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final VoidCallback onTap;

  const ActionField({
    Key? key,
    required this.icon,
    required this.label,
    required this.value,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 4),
      leading: Icon(icon),
      title: Text(label, style: const TextStyle(fontSize: 12)),
      subtitle: Text(
        value,
        style: const TextStyle(fontWeight: FontWeight.w600),
      ),
    );
  }
}

class Popular extends StatelessWidget {
  final ValueChanged<String> onSelect;

  const Popular({Key? key, required this.onSelect}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    const destinations = [
      'CDMX, Ciudad de México',
      'Guadalajara, Jalisco',
      'Monterrey, Nuevo León',
      'Tijuana, Baja California',
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Destinos populares',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: destinations
                  .map(
                    (destination) => GestureDetector(
                      onTap: () => onSelect(destination),
                      child: Container(
                        width: 145,
                        height: 85,
                        margin: const EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          gradient: const LinearGradient(
                            colors: [Color(0xFF135B7A), Color(0xFF08A65A)],
                          ),
                        ),
                        alignment: Alignment.bottomLeft,
                        padding: const EdgeInsets.all(9),
                        child: Text(
                          destination.split(',').first,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class SafetyCard extends StatelessWidget {
  final AppStore store;
  const SafetyCard({Key? key, required this.store}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      child: Card(
        color: dark,
        child: ListTile(
          leading: const Icon(
            Icons.verified_user,
            color: Color(0xFF28D97B),
            size: 36,
          ),
          title: const Text(
            'Viajes seguros',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          subtitle: const Text(
            'Verificación, calificaciones y herramientas de seguridad.',
            style: TextStyle(color: Colors.white70),
          ),
          trailing: TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => SafetyScreen(store: store)),
              );
            },
            child: const Text('Ver'),
          ),
        ),
      ),
    );
  }
}

class Benefits extends StatelessWidget {
  const Benefits({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(12, 0, 12, 20),
      child: Row(
        children: [
          Expanded(
            child: Benefit(
              icon: Icons.directions_car,
              title: 'Publica',
              text: 'Comparte tu ruta',
            ),
          ),
          Expanded(
            child: Benefit(
              icon: Icons.savings,
              title: 'Ahorra',
              text: 'Comparte gastos',
            ),
          ),
          Expanded(
            child: Benefit(
              icon: Icons.shield,
              title: 'Tranquilo',
              text: 'Verificación',
            ),
          ),
          Expanded(
            child: Benefit(
              icon: Icons.people,
              title: 'Conoce',
              text: 'Comunidad',
            ),
          ),
        ],
      ),
    );
  }
}

class Benefit extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const Benefit({
    Key? key,
    required this.icon,
    required this.title,
    required this.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 4),
        CircleAvatar(
          backgroundColor: Color(0xFFE2F6EC),
          child: Icon(icon, color: green),
        ),
        const SizedBox(height: 5),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)),
      ],
    );
  }
}

class ResultsScreen extends StatelessWidget {
  final AppStore store;
  final String origin;
  final String destination;
  final DateTime date;
  final int passengers;

  const ResultsScreen({
    Key? key,
    required this.store,
    required this.origin,
    required this.destination,
    required this.date,
    required this.passengers,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Buscar viajes')),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: store.firebase.tripsStream(),
        builder: (context, snap) {
          final remote = snap.data?.map((item) => Trip.fromJson(item)).toList();
          final all = (remote ?? store.trips).where((t) => t.status == 'active').toList();
          final matches = all.where((trip) {
            return trip.origin.toLowerCase().contains(origin.split(',').first.toLowerCase()) &&
                trip.destination.toLowerCase().contains(destination.split(',').first.toLowerCase());
          }).toList();
          return ListView(padding: const EdgeInsets.all(12), children: [
            Text('$origin → $destination', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('${date.day}/${date.month}/${date.year} · $passengers pasajero(s)', style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 12),
            if (snap.hasError) const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('No se pudieron cargar los viajes. Revisa tu conexión.'))),
            if (matches.isEmpty && !snap.hasError) const Card(child: Padding(padding: EdgeInsets.all(22), child: Text('No encontramos viajes con esos datos todavía. Puedes publicar el tuyo.'))),
            ...matches.map((trip) => TripCard(trip: trip, store: store)),
          ]);
        },
      ),
    );
  }
}

class TripCard extends StatelessWidget {
  final Trip trip;
  final AppStore store;

  const TripCard({
    Key? key,
    required this.trip,
    required this.store,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => TripDetail(trip: trip, store: store),
            ),
          );
        },
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                children: [
                  const CircleAvatar(child: Icon(Icons.person)),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          trip.driver,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const Text(
                          '★ 4.8 · Verificado',
                          style: TextStyle(color: Colors.orange),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    trip.price,
                    style: const TextStyle(
                      color: green,
                      fontWeight: FontWeight.bold,
                      fontSize: 19,
                    ),
                  ),
                ],
              ),
              const Divider(),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${trip.time}\n${trip.origin.split(',').first} → ${trip.destination.split(',').first}',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('${trip.seats} asientos'),
                      Text(
                        trip.vehicle,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black54,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class TripDetail extends StatefulWidget {
  final Trip trip;
  final AppStore store;

  const TripDetail({
    Key? key,
    required this.trip,
    required this.store,
  }) : super(key: key);

  @override
  State<TripDetail> createState() => _TripDetailState();
}

class _TripDetailState extends State<TripDetail> {
  bool loading = false;

  Future<void> reserve() async {
    if (widget.trip.id.isEmpty) return;
    int available;
    try {
      available = await widget.store.firebase.getCurrentAvailableSeats(widget.trip.id);
    } catch (_) {
      available = int.tryParse(widget.trip.seats) ?? 0;
    }
    if (available < 1) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No hay asientos disponibles en este momento.')));
      }
      return;
    }
    var selected = 1;
    final result = await showDialog<int>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('¿Cuántos asientos necesitas?'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Hay $available asientos disponibles.'),
              const SizedBox(height: 18),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    onPressed: selected > 1 ? () => setDialogState(() => selected--) : null,
                    icon: const Icon(Icons.remove_circle_outline),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Text('$selected', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                  ),
                  IconButton(
                    onPressed: selected < available ? () => setDialogState(() => selected++) : null,
                    icon: const Icon(Icons.add_circle_outline),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text('Total: ${widget.trip.price} × $selected'),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, selected), child: const Text('Solicitar reserva')),
          ],
        ),
      ),
    );
    if (result == null) return;

    setState(() => loading = true);
    try {
      final success = await widget.store.addBooking(widget.trip, result);
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(success ? 'Solicitud enviada al conductor.' : 'No hay suficientes asientos disponibles o ya tienes una solicitud.')),
      );
      if (success) setState(() {});
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo reservar: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final reserved = widget.store.hasBooking(widget.trip);

    return Scaffold(
      appBar: AppBar(title: const Text('Detalle del viaje')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const CircleAvatar(
            radius: 34,
            child: Icon(Icons.person, size: 38),
          ),
          const SizedBox(height: 8),
          Center(
            child: Text(
              '${widget.trip.driver} · ★ 4.8 · Verificado',
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 17,
              ),
            ),
          ),
          const SizedBox(height: 18),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${widget.trip.origin} → ${widget.trip.destination}',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text('${widget.trip.date} · ${widget.trip.time}'),
                  Text('${widget.trip.seats} asientos disponibles'),
                  Text(widget.trip.vehicle),
                  const SizedBox(height: 12),
                  const Text(
                    'Compartir gastos del viaje',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'El monto mostrado corresponde a la aportación por asiento.',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 52,
            child: FilledButton(
              onPressed: loading || reserved ? null : reserve,
              child: Text(
                reserved ? 'Solicitud enviada' : 'Elegir asientos · ${widget.trip.price}',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PublishScreen extends StatefulWidget {
  final AppStore store;

  const PublishScreen({Key? key, required this.store}) : super(key: key);

  @override
  State<PublishScreen> createState() => _PublishScreenState();
}

class _PublishScreenState extends State<PublishScreen> {
  final originController =
      TextEditingController(text: 'Monterrey, Nuevo León');
  final destinationController =
      TextEditingController(text: 'CDMX, Ciudad de México');
  final priceController = TextEditingController(text: '420');

  int seats = 3;
  DateTime date = DateTime(2026, 10, 5);
  TimeOfDay time = const TimeOfDay(hour: 8, minute: 0);

  Future<void> submit() async {
    final trip = Trip(
      origin: originController.text.trim(),
      destination: destinationController.text.trim(),
      date: '${date.day}/${date.month}/${date.year}',
      time: time.format(context),
      price: '\$${priceController.text.trim()}',
      seats: '$seats',
      vehicle: widget.store.vehicleDetails.isEmpty ? 'Vehículo registrado' : widget.store.vehicleDetails,
      driver: widget.store.name.isEmpty ? 'Mi viaje' : widget.store.name,
        driverPhone: widget.store.phone,
    );

    await widget.store.addTrip(trip);
    if (!mounted) return;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('¡Viaje publicado!'),
        content: const Text(
          'Tu viaje se publicó y ahora está disponible para otros usuarios de conrumbo.',
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Listo'),
          ),
        ],
      ),
    );

    if (mounted) Navigator.pop(context);
  }

  @override
  void dispose() {
    originController.dispose();
    destinationController.dispose();
    priceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Publicar viaje')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            '1 · Ruta',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Field(
            icon: Icons.location_on,
            color: green,
            label: 'Origen',
            controller: originController,
          ),
          Field(
            icon: Icons.location_on,
            color: Colors.red,
            label: 'Destino',
            controller: destinationController,
          ),
          const SizedBox(height: 12),
          const Text(
            '2 · Fecha y hora',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          ActionField(
            icon: Icons.calendar_month,
            label: 'Fecha',
            value: '${date.day}/${date.month}/${date.year}',
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 365)),
                initialDate: date,
              );
              if (picked != null) setState(() => date = picked);
            },
          ),
          ActionField(
            icon: Icons.schedule,
            label: 'Hora de salida',
            value: time.format(context),
            onTap: () async {
              final picked = await showTimePicker(
                context: context,
                initialTime: time,
              );
              if (picked != null) setState(() => time = picked);
            },
          ),
          const SizedBox(height: 8),
          const Text(
            '3 · Asientos y aportación',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          ListTile(
            title: const Text('Asientos disponibles'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  onPressed:
                      seats > 1 ? () => setState(() => seats--) : null,
                  icon: const Icon(Icons.remove_circle_outline),
                ),
                Text('$seats'),
                IconButton(
                  onPressed:
                      seats < 7 ? () => setState(() => seats++) : null,
                  icon: const Icon(Icons.add_circle_outline),
                ),
              ],
            ),
          ),
          TextField(
            controller: priceController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Aportación por asiento',
              prefixText: '\$ ',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          const SizedBox(height: 24),
          SizedBox(
            height: 52,
            child: FilledButton(
              onPressed: submit,
              child: const Text(
                'Publicar viaje',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AdminPanelScreen extends StatefulWidget {
  final AppStore store;
  const AdminPanelScreen({Key? key, required this.store}) : super(key: key);

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  Future<void> toggleBlocked(String uid, bool blocked, String name) async {
    try {
      await widget.store.firebase.adminSetBlocked(uid, !blocked);
      await widget.store.firebase.adminLogAction(
        action: !blocked ? 'block_user' : 'unblock_user',
        targetUserId: uid,
        details: name,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(!blocked ? 'Usuario bloqueado' : 'Usuario desbloqueado')),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo actualizar: $e')));
    }
  }

  Future<void> replyTicket(String id, String currentReply) async {
    final controller = TextEditingController(text: currentReply);
    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Responder soporte'),
        content: TextField(
          controller: controller,
          maxLines: 5,
          decoration: const InputDecoration(labelText: 'Respuesta', border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Guardar')),
        ],
      ),
    );
    if (result == null || result.isEmpty) return;
    await widget.store.firebase.adminReplyTicket(id, result, 'answered');
    if (mounted) setState(() {});
  }

  Future<void> resolveReport(String id) async {
    await widget.store.firebase.adminUpdateReport(id, 'resolved');
    if (mounted) setState(() {});
  }

  Future<void> deleteReport(String id) async {
    try {
      await widget.store.firebase.adminDeleteReport(id);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reporte eliminado.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo borrar el reporte: $e')));
    }
  }

  Future<void> deleteTicket(String id) async {
    try {
      await widget.store.firebase.adminDeleteTicket(id);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Solicitud de soporte eliminada.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo borrar soporte: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (widget.store.role != 'admin') {
      return Scaffold(
        appBar: AppBar(title: const Text('Panel de administración')),
        body: const Center(child: Text('Acceso no autorizado')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Panel de administración')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                const CircleAvatar(child: Icon(Icons.admin_panel_settings)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                  Text('Administrador', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  Text('Gestiona usuarios, reportes y soporte'),
                ])),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          const Text('Usuarios', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          StreamBuilder(
            stream: widget.store.firebase.adminUsers(),
            builder: (context, snapshot) {
              if (snapshot.hasError) return const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('No se pudieron cargar los usuarios.')));
              if (!snapshot.hasData) return const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()));
              final docs = snapshot.data!.docs.where((doc) => '${doc.data()['status'] ?? ''}' != 'deleted').toList();
              if (docs.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Todavía no hay usuarios.')));
              return Card(
                child: Column(children: docs.map<Widget>((doc) {
                  final d = doc.data() as Map<String, dynamic>;
                  final uid = doc.id;
                  final name = '${d['name'] ?? 'Sin nombre'}';
                  final email = '${d['email'] ?? ''}';
                  final role = '${d['role'] ?? 'user'}';
                  final blocked = d['blocked'] == true;
                  final isMe = uid == widget.store.firebase.currentUser?.uid;
                  return ListTile(
                    leading: CircleAvatar(child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?')),
                    title: Text(name),
                    subtitle: Text('$email\n${role == 'admin' ? 'ADMIN' : 'Usuario'}${blocked ? ' · BLOQUEADO' : ''}'),
                    isThreeLine: true,
                    trailing: isMe
                        ? const Chip(label: Text('Tú'))
                        : IconButton(
                            tooltip: blocked ? 'Desbloquear' : 'Bloquear',
                            icon: Icon(blocked ? Icons.lock_open : Icons.block),
                            onPressed: () => toggleBlocked(uid, blocked, name),
                          ),
                  );
                }).toList()),
              );
            },
          ),
          const SizedBox(height: 20),
          const Text('Reportes', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          StreamBuilder(
            stream: widget.store.firebase.adminReports(),
            builder: (context, snapshot) {
              if (snapshot.hasError) return const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('No se pudieron cargar los reportes.')));
              if (!snapshot.hasData) return const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()));
              final docs = snapshot.data!.docs.where((doc) => '${doc.data()['status'] ?? ''}' != 'deleted').toList();
              if (docs.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('No hay reportes.')));
              return Card(child: Column(children: docs.map<Widget>((doc) {
                final d = doc.data() as Map<String, dynamic>;
                final status = '${d['status'] ?? 'open'}';
                return ListTile(
                  leading: Icon(status == 'resolved' ? Icons.check_circle : Icons.warning_amber, color: status == 'resolved' ? green : Colors.orange),
                  title: Text('${d['reason'] ?? 'Reporte'}'),
                  subtitle: Text('Reportado: ${d['reportedUserId'] ?? ''}\n${d['details'] ?? ''}'),
                  isThreeLine: true,
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [if (status != 'resolved') IconButton(icon: const Icon(Icons.check), tooltip: 'Resolver', onPressed: () => resolveReport(doc.id)), IconButton(icon: const Icon(Icons.delete_outline), tooltip: 'Borrar', onPressed: () => deleteReport(doc.id))]),
                );
              }).toList()));
            },
          ),
          const SizedBox(height: 20),
          const Text('Soporte', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          StreamBuilder(
            stream: widget.store.firebase.adminTickets(),
            builder: (context, snapshot) {
              if (snapshot.hasError) return const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('No se pudieron cargar las solicitudes de soporte.')));
              if (!snapshot.hasData) return const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()));
              final docs = snapshot.data!.docs.where((doc) => '${doc.data()['status'] ?? ''}' != 'deleted').toList();
              if (docs.isEmpty) return const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('No hay solicitudes de soporte.')));
              return Card(child: Column(children: docs.map<Widget>((doc) {
                final d = doc.data() as Map<String, dynamic>;
                final status = '${d['status'] ?? 'open'}';
                return ListTile(
                  leading: const Icon(Icons.support_agent),
                  title: Text('${d['subject'] ?? 'Ayuda'}'),
                  subtitle: Text('${d['message'] ?? ''}\nRespuesta: ${d['adminReply'] ?? 'Pendiente'}'),
                  isThreeLine: true,
                  onTap: () => replyTicket(doc.id, '${d['adminReply'] ?? ''}'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [Chip(label: Text(status)), IconButton(icon: const Icon(Icons.delete_outline), tooltip: 'Borrar', onPressed: () => deleteTicket(doc.id))]),
                );
              }).toList()));
            },
          ),
        ],
      ),
    );
  }
}

class ProfileScreen extends StatelessWidget {
  final AppStore store;
  const ProfileScreen({Key? key, required this.store}) : super(key: key);

  Future<void> edit(BuildContext context) async {
    final name = TextEditingController(text: store.name);
    final phone = TextEditingController(text: store.phone);
    final identity = TextEditingController(text: store.identity);
    final age = TextEditingController(text: store.age > 0 ? '${store.age}' : '');
    final ine = TextEditingController(text: store.ine);
    final license = TextEditingController(text: store.license);
    final vehicle = TextEditingController(text: store.vehicleDetails);
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Editar perfil y verificaciones'),
        content: SingleChildScrollView(
          child: Column(children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nombre')),
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Teléfono')),
            TextField(controller: age, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Edad (obligatoria)')),
            TextField(controller: ine, decoration: const InputDecoration(labelText: 'INE (obligatoria)')), 
            TextField(controller: identity, decoration: const InputDecoration(labelText: 'Identidad (nombre completo)')),
            TextField(controller: license, decoration: const InputDecoration(labelText: 'Licencia de conducir')),
            TextField(controller: vehicle, decoration: const InputDecoration(labelText: 'Vehículo (marca, modelo, placas)')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
          FilledButton(onPressed: () async { await store.updateProfile(newName: name.text.trim(), newPhone: phone.text.trim(), newIdentity: identity.text.trim(), newLicense: license.text.trim(), newVehicle: vehicle.text.trim(), newAge: int.tryParse(age.text.trim()) ?? 0, newIne: ine.text.trim()); if (context.mounted) Navigator.pop(context); }, child: const Text('Guardar')),
        ],
      ),
    );
  }

  Future<void> logout(BuildContext context) async {
    await store.logout();
    if (!context.mounted) return;
    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => AuthScreen(store: store)), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mi perfil'), actions: [IconButton(onPressed: () => edit(context), icon: const Icon(Icons.edit))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const CircleAvatar(radius: 45, child: Icon(Icons.person, size: 52)),
        const SizedBox(height: 10),
        Center(child: Text(store.name.isEmpty ? 'Usuario conrumbo' : store.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
        Center(child: Text(store.email)),
        if (store.phone.isNotEmpty) Center(child: Text(store.phone)),
        const SizedBox(height: 20),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.verified_user, color: green), title: const Text('Verificación'), subtitle: Text('${store.name.isEmpty ? 'Nombre pendiente' : 'Nombre capturado'} · ${store.age > 0 ? 'Edad capturada' : 'Edad pendiente'} · ${store.ine.isEmpty ? 'INE pendiente' : 'INE capturada'}'), trailing: Text(store.verified ? 'Completa' : 'Pendiente')),
          ListTile(leading: const Icon(Icons.verified_user, color: green), title: const Text('Identidad'), trailing: Text(store.identity.isEmpty ? 'Pendiente' : 'Capturada')),
          ListTile(leading: const Icon(Icons.drive_eta, color: green), title: const Text('Licencia de conducir'), trailing: Text(store.license.isEmpty ? 'Pendiente' : 'Capturada')),
          ListTile(leading: const Icon(Icons.directions_car, color: green), title: const Text('Vehículo'), subtitle: store.vehicleDetails.isEmpty ? null : Text(store.vehicleDetails), trailing: Text(store.vehicleDetails.isEmpty ? 'Agregar' : 'Capturado')),
          ListTile(leading: const Icon(Icons.edit, color: green), title: const Text('Editar datos'), onTap: () => edit(context), trailing: const Icon(Icons.chevron_right)),
        ])),
        const SizedBox(height: 12),
        Card(child: Column(children: [
          ListTile(leading: const Icon(Icons.route), title: const Text('Mis viajes'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MyTripsScreen(store: store))), trailing: const Icon(Icons.chevron_right)),
          ListTile(leading: const Icon(Icons.event_seat, color: green), title: const Text('Mis reservas'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MyBookingsScreen(store: store))), trailing: const Icon(Icons.chevron_right)),
          ListTile(leading: const Icon(Icons.security), title: const Text('Centro de seguridad'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SafetyScreen(store: store))), trailing: const Icon(Icons.chevron_right)),
          if (store.role == 'admin') ListTile(leading: const Icon(Icons.admin_panel_settings, color: green), title: const Text('Panel de administración'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AdminPanelScreen(store: store))), trailing: const Icon(Icons.chevron_right)),
          ListTile(leading: const Icon(Icons.logout), title: const Text('Cerrar sesión'), onTap: () => logout(context)),
        ])),
      ]),
    );
  }
}

class ChatScreen extends StatefulWidget {
  final String contactName;
  final String phone;
  const ChatScreen({Key? key, required this.contactName, required this.phone}) : super(key: key);
  @override State<ChatScreen> createState() => _ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  final messages = <String>[];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chat con ${widget.contactName}'),
        actions: [
          if (widget.phone.isNotEmpty)
            IconButton(
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Teléfono: ${widget.phone}')),
              ),
              icon: const Icon(Icons.phone),
            ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: messages.isEmpty
                ? const Center(child: Text('Envía un mensaje para contactar.'))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: messages.length,
                    itemBuilder: (_, i) => Align(
                      alignment: Alignment.centerRight,
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Text(messages[i]),
                        ),
                      ),
                    ),
                  ),
          ),
          SafeArea(
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    decoration: const InputDecoration(
                      hintText: 'Escribe un mensaje...',
                      contentPadding: EdgeInsets.symmetric(horizontal: 12),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    final text = controller.text.trim();
                    if (text.isEmpty) return;
                    setState(() {
                      messages.add(text);
                      controller.clear();
                    });
                  },
                  icon: const Icon(Icons.send, color: green),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class EditTripScreen extends StatefulWidget {
  final AppStore store;
  final Trip trip;
  const EditTripScreen({Key? key, required this.store, required this.trip}) : super(key: key);

  @override
  State<EditTripScreen> createState() => _EditTripScreenState();
}

class _EditTripScreenState extends State<EditTripScreen> {
  late final TextEditingController origin;
  late final TextEditingController destination;
  late final TextEditingController date;
  late final TextEditingController time;
  late final TextEditingController price;
  late final TextEditingController seats;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    origin = TextEditingController(text: widget.trip.origin);
    destination = TextEditingController(text: widget.trip.destination);
    date = TextEditingController(text: widget.trip.date);
    time = TextEditingController(text: widget.trip.time);
    price = TextEditingController(text: widget.trip.price.replaceAll(RegExp(r'[^0-9.]'), ''));
    seats = TextEditingController(text: widget.trip.totalSeats == '0' ? widget.trip.seats : widget.trip.totalSeats);
  }

  Future<void> save() async {
    final seatCount = int.tryParse(seats.text.trim()) ?? 0;
    if (origin.text.trim().isEmpty || destination.text.trim().isEmpty || date.text.trim().isEmpty || time.text.trim().isEmpty || price.text.trim().isEmpty || seatCount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Completa todos los datos del viaje.')));
      return;
    }
    setState(() => saving = true);
    try {
      final updated = Trip(
        id: widget.trip.id, driverId: widget.trip.driverId,
        origin: origin.text.trim(), destination: destination.text.trim(),
        date: date.text.trim(), time: time.text.trim(),
        price: '\$${price.text.trim()}', seats: widget.trip.seats, totalSeats: '$seatCount',
        vehicle: widget.trip.vehicle, driver: widget.trip.driver, driverPhone: widget.trip.driverPhone, status: widget.trip.status,
      );
      await widget.store.updateTrip(updated);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo editar el viaje: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Editar viaje')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: origin, decoration: const InputDecoration(labelText: 'Origen', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: destination, decoration: const InputDecoration(labelText: 'Destino', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: date, decoration: const InputDecoration(labelText: 'Fecha', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: time, decoration: const InputDecoration(labelText: 'Hora', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: seats, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Asientos totales del viaje', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Aportación por asiento', prefixText: '\$ ', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        ListTile(leading: const Icon(Icons.directions_car, color: green), title: const Text('Vehículo'), subtitle: Text(widget.trip.vehicle)),
        const SizedBox(height: 20),
        SizedBox(height: 52, child: FilledButton(onPressed: saving ? null : save, child: saving ? const CircularProgressIndicator() : const Text('Guardar cambios'))),
      ]),
    );
  }

  @override
  void dispose() {
    origin.dispose(); destination.dispose(); date.dispose(); time.dispose(); price.dispose(); seats.dispose(); super.dispose();
  }
}

class MyTripsScreen extends StatefulWidget {
  final AppStore store;
  const MyTripsScreen({Key? key, required this.store}) : super(key: key);
  @override State<MyTripsScreen> createState() => _MyTripsScreenState();
}

class _MyTripsScreenState extends State<MyTripsScreen> {
  Booking bookingFromDoc(QueryDocumentSnapshot<Map<String, dynamic>> doc) =>
      Booking.fromJson({...doc.data(), 'id': doc.id});

  Future<void> changeBooking(String id, String status) async {
    try {
      await widget.store.firebase.driverUpdateBooking(id, status);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(status == 'accepted' ? 'Reserva aceptada.' : 'Reserva rechazada y asientos liberados.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo actualizar la reserva: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final uid = widget.store.firebase.currentUser?.uid;
    final mine = widget.store.trips.where((trip) => uid != null && trip.driverId == uid).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Mis viajes')),
      body: mine.isEmpty
          ? const Center(child: Text('Todavía no tienes viajes publicados.'))
          : StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
              stream: widget.store.firebase.driverBookings(),
              builder: (context, snapshot) {
                final bookings = snapshot.data?.docs.map(bookingFromDoc).toList() ?? <Booking>[];
                return ListView(
                  padding: const EdgeInsets.all(12),
                  children: mine.map((trip) {
                    final related = bookings.where((b) => b.tripId == trip.id).toList();
                    return Card(
                      child: Column(children: [
                        ListTile(
                          leading: const Icon(Icons.route, color: green),
                          title: Text('${trip.origin.split(',').first} → ${trip.destination.split(',').first}'),
                          subtitle: Text('${trip.date} · ${trip.time}\n${trip.seats} asientos disponibles de ${trip.totalSeats}'),
                          isThreeLine: true,
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) async {
                              if (value == 'edit') {
                                final changed = await Navigator.push(context, MaterialPageRoute(builder: (_) => EditTripScreen(store: widget.store, trip: trip)));
                                if (changed == true && mounted) setState(() {});
                              } else if (value == 'cancel') {
                                await widget.store.changeTripStatus(trip, 'cancelled');
                                if (mounted) setState(() {});
                              } else if (value == 'complete') {
                                await widget.store.changeTripStatus(trip, 'completed');
                                if (mounted) setState(() {});
                              } else if (value == 'delete') {
                                final ok = await showDialog<bool>(
                                  context: context,
                                  builder: (c) => AlertDialog(
                                    title: const Text('Borrar viaje'),
                                    content: const Text('¿Seguro que quieres borrar este viaje? Esta acción no se puede deshacer.'),
                                    actions: [
                                      TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('No')),
                                      FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Sí, borrar')),
                                    ],
                                  ),
                                );
                                if (ok == true) {
                                  try {
                                    await widget.store.deleteTrip(trip);
                                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Viaje borrado.')));
                                    if (mounted) setState(() {});
                                  } catch (e) {
                                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo borrar: $e')));
                                  }
                                }
                              }
                            },
                            itemBuilder: (_) => [
                              if (trip.status == 'active') ...[
                                const PopupMenuItem(value: 'edit', child: Text('Editar viaje')),
                                const PopupMenuItem(value: 'cancel', child: Text('Cancelar viaje')),
                                const PopupMenuItem(value: 'complete', child: Text('Finalizar viaje')),
                              ],
                              if (trip.status != 'active') const PopupMenuItem(value: 'delete', child: Text('Borrar viaje')),
                            ],
                          ),
                        ),
                        if (trip.status != 'active')
                          ListTile(
                            leading: Icon(trip.status == 'cancelled' ? Icons.cancel : Icons.check_circle, color: trip.status == 'cancelled' ? Colors.red : green),
                            title: Text(trip.status == 'cancelled' ? 'Viaje cancelado' : 'Viaje finalizado'),
                            subtitle: const Text('Puedes borrarlo definitivamente desde el menú.'),
                          ),
                        if (trip.status != 'active')
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                            child: SizedBox(
                              width: double.infinity,
                              child: OutlinedButton.icon(
                                icon: const Icon(Icons.delete_outline, color: Colors.red),
                                label: const Text('Borrar viaje definitivamente'),
                                onPressed: () async {
                                  final ok = await showDialog<bool>(
                                    context: context,
                                    builder: (c) => AlertDialog(
                                      title: const Text('Borrar viaje'),
                                      content: const Text('¿Seguro que quieres borrar este viaje? Esta acción no se puede deshacer.'),
                                      actions: [
                                        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('No')),
                                        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Sí, borrar')),
                                      ],
                                    ),
                                  );
                                  if (ok != true) return;
                                  try {
                                    await widget.store.deleteTrip(trip);
                                    if (mounted) {
                                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Viaje borrado.')));
                                      setState(() {});
                                    }
                                  } catch (e) {
                                    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo borrar: $e')));
                                  }
                                },
                              ),
                            ),
                          ),
                        if (related.isNotEmpty) const Divider(height: 1),
                        ...related.map((b) => ListTile(
                          leading: CircleAvatar(child: Text(b.passenger.isNotEmpty ? b.passenger[0].toUpperCase() : '?')),
                          title: Text('${b.passenger} · ${b.seats} asiento(s)'),
                          subtitle: Text('${b.status == 'pending' ? 'Pendiente de aceptar' : b.status == 'accepted' ? 'Aceptada' : b.status == 'rejected' ? 'Rechazada' : 'Cancelada'}\n${b.passengerPhone.isEmpty ? 'Teléfono no registrado' : b.passengerPhone}'),
                          isThreeLine: true,
                          trailing: b.status == 'pending'
                              ? Wrap(spacing: 2, children: [
                                  IconButton(tooltip: 'Aceptar', icon: const Icon(Icons.check_circle, color: green), onPressed: () => changeBooking(b.id, 'accepted')),
                                  IconButton(tooltip: 'Rechazar', icon: const Icon(Icons.cancel, color: Colors.red), onPressed: () => changeBooking(b.id, 'rejected')),
                                ])
                              : IconButton(icon: const Icon(Icons.chat, color: green), onPressed: b.passengerPhone.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(contactName: b.passenger, phone: b.passengerPhone)))),
                        )),
                      ]),
                    );
                  }).toList(),
                );
              },
            ),
    );
  }
}

class MyBookingsScreen extends StatelessWidget {
  final AppStore store;
  const MyBookingsScreen({Key? key, required this.store}) : super(key: key);

  Booking bookingFromDoc(QueryDocumentSnapshot<Map<String, dynamic>> doc) => Booking.fromJson({...doc.data(), 'id': doc.id});

  Future<void> cancel(BuildContext context, Booking b) async {
    try {
      await store.firebase.cancelBooking(b.id);
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reserva cancelada. Los asientos volvieron a estar disponibles.')));
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo cancelar: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mis reservas')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: store.firebase.myBookings(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('No se pudieron cargar las reservas: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final bookings = snapshot.data!.docs.map(bookingFromDoc).toList();
          if (bookings.isEmpty) return const Center(child: Text('Todavía no tienes reservas.'));
          return ListView(
            padding: const EdgeInsets.all(12),
            children: bookings.map((b) => Card(child: Column(children: [
              ListTile(
                leading: const Icon(Icons.event_seat, color: green),
                title: Text('${b.origin.split(',').first} → ${b.destination.split(',').first}'),
                subtitle: Text('${b.date} · ${b.time}\nConductor: ${b.driver} · ${b.vehicle}\n${b.seats} asiento(s) · ${b.status == 'pending' ? 'Pendiente de aceptación' : b.status == 'accepted' ? 'Aceptada' : b.status == 'rejected' ? 'Rechazada' : 'Cancelada'}'),
                isThreeLine: true,
                trailing: Text(b.price, style: const TextStyle(fontWeight: FontWeight.bold, color: green)),
              ),
              if (b.status == 'pending' || b.status == 'accepted')
                ListTile(
                  leading: const Icon(Icons.cancel_outlined, color: Colors.red),
                  title: const Text('Cancelar reservación'),
                  subtitle: const Text('Los asientos volverán a estar disponibles.'),
                  onTap: () => cancel(context, b),
                ),
              if (b.status == 'accepted')
                ListTile(
                  leading: const Icon(Icons.chat, color: green),
                  title: Text('Contactar a ${b.driver}'),
                  subtitle: Text(b.driverPhone.isEmpty ? 'Agrega tu teléfono para habilitar contacto directo' : b.driverPhone),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: b.driverPhone.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(contactName: b.driver, phone: b.driverPhone))),
                ),
            ]))).toList(),
          );
        },
      ),
    );
  }
}

class SafetyScreen extends StatelessWidget {
  final AppStore store;
  const SafetyScreen({Key? key, required this.store}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Centro de seguridad')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SafetyItem(
            icon: Icons.verified_user,
            title: 'Verificación de identidad',
            subtitle: 'Ayuda a crear una comunidad de confianza.',
          ),
          const SafetyItem(
            icon: Icons.directions_car,
            title: 'Vehículos verificados',
            subtitle: 'Información del vehículo antes de viajar.',
          ),
          const SafetyItem(
            icon: Icons.star,
            title: 'Calificaciones',
            subtitle: 'Consulta las opiniones de otros usuarios.',
          ),
          SafetyItem(
            icon: Icons.report_problem,
            title: 'Reportar un problema',
            subtitle: 'Envía un reporte al equipo de conrumbo.',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReportProblemScreen(store: store))),
          ),
          SafetyItem(
            icon: Icons.support_agent,
            title: 'Ayuda y soporte',
            subtitle: 'Envía una solicitud y recibe respuesta.',
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SupportScreen(store: store))),
          ),
        ],
      ),
    );
  }
}

class SafetyItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  const SafetyItem({
    Key? key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: green),
        title: Text(title),
        subtitle: Text(subtitle),
        onTap: onTap,
        trailing: onTap == null ? null : const Icon(Icons.chevron_right),
      ),
    );
  }
}

class ReportProblemScreen extends StatefulWidget {
  final AppStore store;
  const ReportProblemScreen({Key? key, required this.store}) : super(key: key);
  @override State<ReportProblemScreen> createState() => _ReportProblemScreenState();
}

class _ReportProblemScreenState extends State<ReportProblemScreen> {
  final reason = TextEditingController();
  final userId = TextEditingController();
  final details = TextEditingController();
  bool sending = false;

  Future<void> submit() async {
    if (reason.text.trim().isEmpty || details.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Escribe el motivo y los detalles.')));
      return;
    }
    setState(() => sending = true);
    try {
      if (!widget.store.loggedIn) throw Exception('Debes iniciar sesión.');
      await widget.store.firebase.report(
        reportedUserId: userId.text.trim(),
        reason: reason.text.trim(),
        details: details.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Reporte enviado correctamente.')));
      Navigator.pop(context);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo enviar: $e')));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reportar un problema')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('El reporte llegará al equipo de administración.'),
        const SizedBox(height: 16),
        TextField(controller: reason, decoration: const InputDecoration(labelText: 'Motivo', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: userId, decoration: const InputDecoration(labelText: 'ID del usuario relacionado (opcional)', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: details, maxLines: 6, decoration: const InputDecoration(labelText: '¿Qué ocurrió?', border: OutlineInputBorder())),
        const SizedBox(height: 18),
        SizedBox(height: 50, child: FilledButton(onPressed: sending || !widget.store.loggedIn ? null : submit, child: sending ? const CircularProgressIndicator() : const Text('Enviar reporte'))),
      ]),
    );
  }
}

class SupportScreen extends StatefulWidget {
  final AppStore store;
  const SupportScreen({Key? key, required this.store}) : super(key: key);
  @override State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  final subject = TextEditingController();
  final message = TextEditingController();
  bool sending = false;

  Future<void> submit() async {
    if (subject.text.trim().isEmpty || message.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Completa asunto y mensaje.')));
      return;
    }
    setState(() => sending = true);
    try {
      if (!widget.store.loggedIn) throw Exception('Debes iniciar sesión.');
      await widget.store.firebase.createSupportTicket(subject: subject.text.trim(), message: message.text.trim());
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Solicitud enviada.')));
      subject.clear(); message.clear();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('No se pudo enviar: $e')));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ayuda y soporte')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        TextField(controller: subject, decoration: const InputDecoration(labelText: 'Asunto', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: message, maxLines: 6, decoration: const InputDecoration(labelText: 'Mensaje', border: OutlineInputBorder())),
        const SizedBox(height: 18),
        SizedBox(height: 50, child: FilledButton(onPressed: sending || !widget.store.loggedIn ? null : submit, child: sending ? const CircularProgressIndicator() : const Text('Enviar a soporte'))),
        const SizedBox(height: 24),
        const Text('Mis solicitudes', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        if (widget.store.loggedIn)
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: widget.store.firebase.mySupportTickets(),
            builder: (context, snapshot) {
              if (snapshot.hasError) return Card(child: Padding(padding: const EdgeInsets.all(16), child: Text('No se pudieron cargar: ${snapshot.error}')));
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snapshot.data!.docs.reversed.toList();
              if (docs.isEmpty) return const Text('Todavía no tienes solicitudes.');
              return Column(children: docs.map((doc) {
                final d = doc.data();
                return Card(child: ListTile(title: Text('${d['subject'] ?? 'Solicitud'}'), subtitle: Text('Estado: ${d['status'] ?? 'open'}\nRespuesta: ${d['adminReply'] ?? 'Pendiente'}')));
              }).toList());
            },
          ),
      ]),
    );
  }
}
