# ConRumbo - corrección de reservas y borrado de viajes

- Las reservas ya no consultan las reservas privadas de otros pasajeros.
- El pasajero reserva usando los asientos disponibles del viaje dentro de una transacción.
- Se evita modificar totalSeats durante una reserva.
- Al borrar un viaje cancelado/finalizado, se eliminan también sus reservas asociadas del mismo conductor.
