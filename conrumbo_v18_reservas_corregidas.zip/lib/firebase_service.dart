import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirebaseService {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore db = FirebaseFirestore.instance;

  User? get currentUser => auth.currentUser;

  Future<UserCredential> register({required String name, required String email, required String password, required String phone, required int age, required String ine}) async {
    final credential = await auth.createUserWithEmailAndPassword(email: email, password: password);
    final uid = credential.user!.uid;
    await db.collection('users').doc(uid).set({
      'uid': uid,
      'name': name,
      'email': email,
      'phone': phone,
      'age': age,
      'ine': ine,
      'verified': true,
      'role': 'user',
      'blocked': false,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return credential;
  }

  Future<UserCredential> login({required String email, required String password}) async {
    final credential = await auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
    await ensureUserProfile(credential.user!);
    return credential;
  }

  Future<void> ensureUserProfile(User user, {String? name, String phone = ''}) async {
    final ref = db.collection('users').doc(user.uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'uid': user.uid,
        'name': (name ?? user.displayName ?? '').trim(),
        'email': user.email ?? '',
        'phone': phone,
        'age': 0,
        'ine': '',
        'verified': false,
        'role': 'user',
        'blocked': false,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<void> logout() => auth.signOut();

  Future<String> createTrip(Map<String, dynamic> data) async {
    final totalSeats = int.tryParse('${data['totalSeats'] ?? data['seats'] ?? 0}') ?? 0;
    final ref = await db.collection('trips').add({
      ...data,
      'driverId': currentUser!.uid,
      'status': 'active',
      'totalSeats': totalSeats,
      'availableSeats': totalSeats,
      'seats': '$totalSeats',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<List<Map<String, dynamic>>> getTrips() async {
    final snap = await db.collection('trips').where('status', isEqualTo: 'active').get();
    return snap.docs.map((d) => {'id': d.id, ...d.data()}).toList();
  }

  Stream<List<Map<String, dynamic>>> tripsStream() => db
      .collection('trips')
      .where('status', isEqualTo: 'active')
      .snapshots()
      .map((snap) => snap.docs.map((d) => {'id': d.id, ...d.data()}).toList());

  Future<bool> createBooking(Map<String, dynamic> data) async {
    final tripId = '${data['tripId'] ?? ''}';
    final passengerId = '${data['passengerId'] ?? ''}';
    final requested = int.tryParse('${data['seatsRequested'] ?? data['seats'] ?? 1}') ?? 1;
    if (tripId.isEmpty || passengerId.isEmpty || requested < 1) return false;

    final tripRef = db.collection('trips').doc(tripId);
    final bookingRef = db.collection('bookings').doc('${tripId}_$passengerId');

    return db.runTransaction<bool>((tx) async {
      final tripSnap = await tx.get(tripRef);
      final existing = await tx.get(bookingRef);
      if (!tripSnap.exists || existing.exists) return false;

      final tripData = tripSnap.data() ?? <String, dynamic>{};
      final available = int.tryParse('${tripData['availableSeats'] ?? tripData['seats'] ?? 0}') ?? 0;
      if (available < requested) return false;

      tx.update(tripRef, {
        'availableSeats': available - requested,
        'seats': '${available - requested}',
        'updatedAt': FieldValue.serverTimestamp(),
      });
      tx.set(bookingRef, {
        ...data,
        'seatsRequested': requested,
        'seats': '$requested',
        'status': 'pending',
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      return true;
    });
  }

  Future<void> setTripTotalSeats(String id, int totalSeats) async {
    await db.collection('trips').doc(id).update({
      'totalSeats': totalSeats,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateTrip(String id, Map<String, dynamic> data) async {
    final totalSeats = int.tryParse('${data['totalSeats'] ?? data['seats'] ?? 0}') ?? 0;
    if (totalSeats < 1) throw Exception('El viaje debe tener al menos 1 asiento.');
    final tripRef = db.collection('trips').doc(id);

    await db.runTransaction((tx) async {
      final tripSnap = await tx.get(tripRef);
      if (!tripSnap.exists) throw Exception('El viaje ya no existe.');
      final current = tripSnap.data() ?? <String, dynamic>{};
      final currentAvailable = int.tryParse('${current['availableSeats'] ?? current['seats'] ?? 0}') ?? 0;
      final currentTotal = int.tryParse('${current['totalSeats'] ?? ''}') ?? currentAvailable;
      final booked = (currentTotal - currentAvailable).clamp(0, currentTotal).toInt();
      if (totalSeats < booked) {
        throw Exception('No puedes reducir los asientos a $totalSeats porque ya hay $booked reservados.');
      }
      final available = totalSeats - booked;
      tx.update(tripRef, {
        ...data,
        'totalSeats': totalSeats,
        'availableSeats': available,
        'seats': '$available',
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> myBookings() => db
      .collection('bookings')
      .where('passengerId', isEqualTo: currentUser!.uid)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> driverBookings() => db
      .collection('bookings')
      .where('driverId', isEqualTo: currentUser!.uid)
      .snapshots();

  Future<List<Map<String, dynamic>>> getDriverBookingsOnce() async {
    final snap = await db.collection('bookings').where('driverId', isEqualTo: currentUser!.uid).get();
    return snap.docs.map((d) => {'id': d.id, ...d.data()}).toList();
  }

  Future<void> cancelBooking(String id) async {
    final bookingRef = db.collection('bookings').doc(id);
    await db.runTransaction((tx) async {
      final bookingSnap = await tx.get(bookingRef);
      if (!bookingSnap.exists) throw Exception('La reserva ya no existe.');
      final data = bookingSnap.data() ?? <String, dynamic>{};
      final passengerId = '${data['passengerId'] ?? ''}';
      if (passengerId != currentUser!.uid) throw Exception('No puedes cancelar esta reserva.');
      final status = '${data['status'] ?? 'pending'}';
      if (status == 'cancelled' || status == 'rejected') return;
      final seats = int.tryParse('${data['seatsRequested'] ?? data['seats'] ?? 1}') ?? 1;
      final tripId = '${data['tripId'] ?? ''}';
      if (tripId.isNotEmpty) {
        final tripRef = db.collection('trips').doc(tripId);
        final tripSnap = await tx.get(tripRef);
        if (tripSnap.exists) {
          final trip = tripSnap.data() ?? <String, dynamic>{};
          final available = int.tryParse('${trip['availableSeats'] ?? trip['seats'] ?? 0}') ?? 0;
          tx.update(tripRef, {
            'availableSeats': available + seats,
            'seats': '${available + seats}',
            'updatedAt': FieldValue.serverTimestamp(),
          });
        }
      }
      tx.update(bookingRef, {'status': 'cancelled', 'updatedAt': FieldValue.serverTimestamp()});
    });
  }

  Future<void> driverUpdateBooking(String id, String status) async {
    if (status != 'accepted' && status != 'rejected') return;
    final bookingRef = db.collection('bookings').doc(id);
    await db.runTransaction((tx) async {
      final bookingSnap = await tx.get(bookingRef);
      if (!bookingSnap.exists) throw Exception('La reserva ya no existe.');
      final data = bookingSnap.data() ?? <String, dynamic>{};
      if ('${data['driverId'] ?? ''}' != currentUser!.uid) throw Exception('No puedes modificar esta reserva.');
      if ('${data['status'] ?? 'pending'}' != 'pending') return;
      if (status == 'rejected') {
        final seats = int.tryParse('${data['seatsRequested'] ?? data['seats'] ?? 1}') ?? 1;
        final tripId = '${data['tripId'] ?? ''}';
        if (tripId.isNotEmpty) {
          final tripRef = db.collection('trips').doc(tripId);
          final tripSnap = await tx.get(tripRef);
          if (tripSnap.exists) {
            final trip = tripSnap.data() ?? <String, dynamic>{};
            final available = int.tryParse('${trip['availableSeats'] ?? trip['seats'] ?? 0}') ?? 0;
            tx.update(tripRef, {
              'availableSeats': available + seats,
              'seats': '${available + seats}',
              'updatedAt': FieldValue.serverTimestamp(),
            });
          }
        }
      }
      tx.update(bookingRef, {'status': status, 'updatedAt': FieldValue.serverTimestamp()});
    });
  }

  Future<void> updateBooking(String id, String status) => driverUpdateBooking(id, status);

  Stream<DocumentSnapshot<Map<String, dynamic>>> userStream(String uid) =>
      db.collection('users').doc(uid).snapshots();

  Future<Map<String, dynamic>> getUserProfile(String uid) async {
    final snap = await db.collection('users').doc(uid).get();
    return snap.data() ?? <String, dynamic>{};
  }

  Future<void> updateProfile(String uid, Map<String, dynamic> data) async {
    final safe = Map<String, dynamic>.from(data)
      ..remove('role')
      ..remove('blocked')
      ..remove('uid')
      ..remove('createdAt');
    safe['updatedAt'] = FieldValue.serverTimestamp();
    await db.collection('users').doc(uid).update(safe);
  }

  Future<String> getRole(String uid) async {
    final data = await getUserProfile(uid);
    return '${data['role'] ?? 'user'}';
  }

  Future<void> report({required String reportedUserId, required String reason, String? tripId, String? details}) async {
    await db.collection('reports').add({
      'reporterId': currentUser!.uid,
      'reportedUserId': reportedUserId,
      'reason': reason,
      'details': details ?? '',
      'tripId': tripId ?? '',
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> createSupportTicket({required String subject, required String message}) async {
    await db.collection('supportTickets').add({
      'userId': currentUser!.uid,
      'userEmail': currentUser!.email ?? '',
      'subject': subject,
      'message': message,
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> mySupportTickets() => db
      .collection('supportTickets')
      .where('userId', isEqualTo: currentUser!.uid)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> adminReports() => db
      .collection('reports')
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> adminTickets() => db
      .collection('supportTickets')
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> adminUsers() => db
      .collection('users')
      .snapshots();

  Future<void> adminLogAction({required String action, required String targetUserId, String details = ''}) async {
    await db.collection('adminActions').add({
      'adminId': currentUser!.uid,
      'action': action,
      'targetUserId': targetUserId,
      'details': details,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminSetBlocked(String uid, bool blocked) async {
    await db.collection('users').doc(uid).update({
      'blocked': blocked,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminUpdateReport(String id, String status) async {
    await db.collection('reports').doc(id).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminDeleteReport(String id) async {
    final ref = db.collection('reports').doc(id);
    try {
      await ref.delete();
    } catch (_) {
      await ref.update({'status': 'deleted', 'deletedAt': FieldValue.serverTimestamp(), 'updatedAt': FieldValue.serverTimestamp()});
    }
  }

  Future<void> adminDeleteTicket(String id) async {
    final ref = db.collection('supportTickets').doc(id);
    try {
      await ref.delete();
    } catch (_) {
      await ref.update({'status': 'deleted', 'deletedAt': FieldValue.serverTimestamp(), 'updatedAt': FieldValue.serverTimestamp()});
    }
  }

  Future<void> adminReplyTicket(String id, String reply, String status) async {
    await db.collection('supportTickets').doc(id).update({
      'adminReply': reply,
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}
