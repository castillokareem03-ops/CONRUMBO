import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirebaseService {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseFirestore db = FirebaseFirestore.instance;

  User? get currentUser => auth.currentUser;

  Future<UserCredential> register({required String name, required String email, required String password, required String phone}) async {
    final credential = await auth.createUserWithEmailAndPassword(email: email, password: password);
    final uid = credential.user!.uid;
    await db.collection('users').doc(uid).set({
      'uid': uid,
      'name': name,
      'email': email,
      'phone': phone,
      'role': 'user',
      'blocked': false,
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return credential;
  }

  Future<UserCredential> login({required String email, required String password}) async {
    final credential = await auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
    await ensureUserProfile(credential.user!);
    return credential;
  }

  Future<void> ensureUserProfile(User user, {String? name, String phone = ''}) async {
    final ref = db.collection('users').doc(user.uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'uid': user.uid,
        'name': (name ?? user.displayName ?? '').trim(),
        'email': user.email ?? '',
        'phone': phone,
        'role': 'user',
        'blocked': false,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<void> logout() => auth.signOut();

  Stream<DocumentSnapshot<Map<String, dynamic>>> userStream(String uid) =>
      db.collection('users').doc(uid).snapshots();

  Future<Map<String, dynamic>> getUserProfile(String uid) async {
    final snap = await db.collection('users').doc(uid).get();
    return snap.data() ?? <String, dynamic>{};
  }

  Future<void> updateProfile(String uid, Map<String, dynamic> data) async {
    final safe = Map<String, dynamic>.from(data)
      ..remove('role')
      ..remove('blocked')
      ..remove('uid')
      ..remove('createdAt');
    safe['updatedAt'] = FieldValue.serverTimestamp();
    await db.collection('users').doc(uid).update(safe);
  }

  Future<String> getRole(String uid) async {
    final data = await getUserProfile(uid);
    return '${data['role'] ?? 'user'}';
  }

  Future<void> report({required String reportedUserId, required String reason, String? tripId, String? details}) async {
    await db.collection('reports').add({
      'reporterId': currentUser!.uid,
      'reportedUserId': reportedUserId,
      'reason': reason,
      'details': details ?? '',
      'tripId': tripId ?? '',
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> createSupportTicket({required String subject, required String message}) async {
    await db.collection('supportTickets').add({
      'userId': currentUser!.uid,
      'userEmail': currentUser!.email ?? '',
      'subject': subject,
      'message': message,
      'status': 'open',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> mySupportTickets() => db
      .collection('supportTickets')
      .where('userId', isEqualTo: currentUser!.uid)
      .orderBy('createdAt', descending: true)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> adminReports() => db
      .collection('reports')
      .orderBy('createdAt', descending: true)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> adminTickets() => db
      .collection('supportTickets')
      .orderBy('createdAt', descending: true)
      .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> adminUsers() => db
      .collection('users')
      .orderBy('createdAt', descending: true)
      .snapshots();

  Future<void> adminLogAction({required String action, required String targetUserId, String details = ''}) async {
    await db.collection('adminActions').add({
      'adminId': currentUser!.uid,
      'action': action,
      'targetUserId': targetUserId,
      'details': details,
      'createdAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminSetBlocked(String uid, bool blocked) async {
    await db.collection('users').doc(uid).update({
      'blocked': blocked,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminUpdateReport(String id, String status) async {
    await db.collection('reports').doc(id).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> adminReplyTicket(String id, String reply, String status) async {
    await db.collection('supportTickets').doc(id).update({
      'adminReply': reply,
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}
